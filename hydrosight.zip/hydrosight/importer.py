"""Import water readings from a CSV file, checking every row before it is saved."""
import csv
import sqlite3
from datetime import datetime
from pathlib import Path

import config
import operations
import validation

TEMPLATE_COLUMNS: tuple[str, ...] = (
    "station_code", "observer_name", "sampled_at", *config.MEASURES, "data_source", "notes")
REQUIRED_COLUMNS: tuple[str, ...] = ("station_code", "observer_name", "sampled_at", "data_source")


def write_template(folder: Path = config.REPORT_DIR) -> Path:
    """Create an empty CSV file with the correct column headings."""
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"import_template_{datetime.now():%Y%m%d_%H%M%S_%f}.csv"
    with path.open("x", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerow(TEMPLATE_COLUMNS)
    return path


def clean_row(row: dict, stations: dict[str, int], observers: dict[str, int]) -> dict:
    """Validate one CSV row and return a record ready to save, or raise ValueError."""
    code = validation.station_code(row.get("station_code") or "")
    if code not in stations:
        raise ValueError(f"Unknown station code {code}. Add the station first.")
    name = validation.required_text(row.get("observer_name") or "")
    if name not in observers:
        raise ValueError(f"Unknown observer {name}. Add the observer first.")
    record = {"station_id": stations[code], "observer_id": observers[name],
              "sampled_at": validation.timestamp(row.get("sampled_at") or "")}
    for name in config.MEASURES:
        record[name] = validation.measurement(row.get(name) or "", name)
    if all(record[name] is None for name in config.MEASURES):
        raise ValueError("The row has no measurements.")
    source = (row.get("data_source") or "").strip().lower()
    if source not in config.DATA_SOURCES:
        raise ValueError(f"data_source must be one of: {', '.join(config.DATA_SOURCES)}.")
    record["data_source"] = source
    record["notes"] = " ".join((row.get("notes") or "").split())[:200]
    return record


def import_readings(conn: sqlite3.Connection, path: Path) -> dict:
    """Save every valid row, skip invalid rows, and report why each was skipped."""
    stations = {s["code"]: s["station_id"] for s in operations.list_records(conn, "stations")}
    observers = {o["name"]: o["observer_id"] for o in operations.list_records(conn, "observers")}
    accepted = 0
    rejected: list[dict] = []
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise ValueError(f"The file is missing columns: {', '.join(missing)}.")
        for line_number, row in enumerate(reader, start=2):   # line 1 holds the headings
            try:
                record = clean_row(row, stations, observers)
                operations.create_record(conn, "readings", record, log=False)
                accepted += 1
            except ValueError as error:
                rejected.append({"line": line_number, "reason": str(error)})
            except sqlite3.IntegrityError:
                rejected.append({"line": line_number,
                                 "reason": "Duplicate: this station already has a reading at that time."})
    operations.log_activity(conn, "import", "readings", None,
                            f"{accepted} accepted, {len(rejected)} rejected from {Path(path).name}")
    return {"accepted": accepted, "rejected": rejected}

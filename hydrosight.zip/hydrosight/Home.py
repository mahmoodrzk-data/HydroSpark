"""HydroSight web app: home page. Run with:  streamlit run Home.py"""
from datetime import datetime

import pandas as pd
import streamlit as st

import analytics
import config
import operations
import reports
import web_common as wc

wc.start_page(f"{config.APP_NAME}: river quality and pollution analytics")
st.write(
    "HydroSight stores river readings and pollution reports, calculates Malaysia's "
    "Department of Environment Water Quality Index (DOE-WQI), checks field readings against "
    "Class IIB limits, tests for trends, and shows which stations need follow-up first. "
    "It is a student prototype for SIM2011 at Universiti Malaya, planned for use on "
    "Sungai Way, Petaling Jaya.")

filters = wc.sidebar_filters()
with wc.connect() as conn:
    stations = operations.list_records(conn, "stations")
    if filters["station_id"] is not None:
        stations = [s for s in stations if s["station_id"] == filters["station_id"]]
    readings = analytics.add_wqi(operations.search_readings(conn, **filters))
    incidents = operations.search_incidents(conn, **filters)

values = [r["wqi"] for r in readings if r["wqi"] is not None]
response = analytics.response_times(incidents, datetime.now().strftime(config.TIME_FORMAT))
tiles = st.columns(6)
tiles[0].metric("Stations", len(stations))
tiles[1].metric("Readings", len(readings))
tiles[2].metric("WQI samples", len(values))
tiles[3].metric("Mean WQI", reports.number(sum(values) / len(values)) if values else "n/a")
tiles[4].metric("Critical field flags", sum(r["flag"] == "CRITICAL" for r in readings))
tiles[5].metric("Unresolved incidents", response["unresolved"])

st.subheader("Stations to check first (lowest mean WQI first)")
ranking = analytics.rank_stations(stations, readings, incidents)
wc.show_table([{
    "Station": r["station"], "Mean WQI": wc.rounded(r["mean_wqi"]),
    "Class": r["wqi_class"] or "-", "Status": r["wqi_status"] or "-",
    "WQI samples": r["wqi_samples"],
    "Field checks passed (%)": wc.rounded(r["screening_score"]),
    "Critical flags": r["critical"], "Incidents": r["incidents"],
    "Open severity": r["open_severity"]} for r in ranking])

left, right = st.columns(2)
with left:
    st.subheader("Monthly mean WQI")
    series = {}
    for station in stations:
        own = [r for r in readings if r["station_id"] == station["station_id"]]
        months = analytics.monthly_means(own, "wqi")
        if months:
            series[station["code"]] = {month: mean for month, _, mean in months}
    if series:
        st.line_chart(pd.DataFrame(series).sort_index())
        st.caption("DOE classes: Class I above 92.7, Class II from 76.5, "
                   "Class III from 51.9, Class IV from 31.0.")
    else:
        st.info("No WQI values yet. The WQI needs BOD, COD, ammoniacal nitrogen and TSS.")
with right:
    st.subheader("Incidents by type")
    counts = analytics.incident_summary(incidents)["by_type"]
    if counts:
        st.bar_chart(pd.Series(dict(counts), name="Incidents"))
    else:
        st.info("No incidents recorded for these filters.")

st.caption("Screening only: these results are not proof of safety, of a pollution source, "
           "or of a legal breach. Use the pages in the sidebar to record data, analyse it, "
           "make reports, run user testing and back up the data.")

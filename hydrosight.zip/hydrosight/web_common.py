"""Shared helpers for the Streamlit web app. Every page imports this module.

The web app reuses the same modules as the command-line program (validation, operations,
wqi, analytics, impact, importer, reports, dashboard, main), so both give the same answers.
"""
import csv
import hmac
import io
import os
import sqlite3
import time
from collections.abc import Callable
from datetime import date, datetime, timedelta
from pathlib import Path

# Streamlit Community Cloud servers run on UTC. Use Malaysian time (UTC+8, no daylight
# saving) so that "now", the future-time check and the activity log match local time.
os.environ["TZ"] = "MYT-8"
if hasattr(time, "tzset"):   # not available on Windows, where the laptop clock is used
    time.tzset()

import streamlit as st

import config
import data_store
import database
import operations
import reports
import seed_data

DB_PATH: Path = Path(os.environ.get("HYDROSIGHT_DB", str(config.DB_PATH)))
LIVE_DIR: Path = config.BASE_DIR / "data" / "live"
SEVERITY_LABELS: dict[int, str] = {1: "1 - minor", 2: "2 - moderate", 3: "3 - serious"}
LOAD_FAILED: str = "nothing, because the saved data in data/live could not be loaded"


def connect():
    """Open the database (commit on success, undo on error, always close)."""
    return database.open_db(DB_PATH)


@st.cache_resource
def prepare_database() -> str:
    """Create the tables once per server start and fill an empty database.

    Saved data in data/live (kept on GitHub) is loaded first. If there is none,
    the SYNTHETIC demo data is loaded. Returns where the data came from.
    """
    database.init_db(DB_PATH)
    with connect() as conn:
        if not data_store.is_empty(conn):
            return "the existing database file"
    try:
        saved = data_store.read_folder(LIVE_DIR)
        if saved:
            with connect() as conn:
                data_store.replace_all(conn, saved)
            return "data/live (the copy saved on GitHub)"
    except (ValueError, UnicodeDecodeError, csv.Error) as error:
        return f"{LOAD_FAILED} ({error})"
    with connect() as conn:
        seed_data.load(conn, seed_data.build_rows())
    return "the SYNTHETIC demo data"


def start_page(title: str) -> str:
    """Set up a page: layout, database, title, login box and data warning."""
    st.set_page_config(page_title=f"{title} | {config.APP_NAME}", page_icon="💧", layout="wide")
    source = prepare_database()
    st.title(title)
    if source.startswith(LOAD_FAILED):
        st.error(f"{source}. Fix the CSV files in data/live on GitHub, then reboot the app.")
    with connect() as conn:
        synthetic = conn.execute(
            "SELECT 1 FROM readings WHERE data_source = 'synthetic' LIMIT 1").fetchone()
    if synthetic:
        st.warning("This copy contains SYNTHETIC test data. It is not real river data.")
    sidebar_login()
    st.sidebar.caption(f"Data loaded from {source}. Times are Malaysian time (UTC+8).")
    return source


def edit_password() -> str | None:
    """The team's edit password from Streamlit secrets, or None if none is set."""
    try:
        value = st.secrets.get("EDIT_PASSWORD")
    except Exception:   # no secrets file at all, which is normal on a laptop
        return None
    return str(value) if value else None


def sidebar_login() -> None:
    """Let team members unlock editing with the team password."""
    password = edit_password()
    if password is None:
        st.session_state["editor"] = True
        st.sidebar.info("Editing is open because no EDIT_PASSWORD is set.")
        return
    if st.session_state.get("editor"):
        st.sidebar.success("Editing unlocked.")
        if st.sidebar.button("Lock editing", key="lock_editing"):
            st.session_state["editor"] = False
            st.rerun()
        return
    typed = st.sidebar.text_input("Team password (to add or change data)", type="password",
                                  key="password_box")
    if typed:
        if hmac.compare_digest(typed.encode(), password.encode()):
            st.session_state["editor"] = True
            st.rerun()
        st.sidebar.error("Wrong password.")


def can_edit() -> bool:
    """True when this visitor may add, change or delete data."""
    return bool(st.session_state.get("editor"))


def require_editor() -> bool:
    """Return True for team members; otherwise explain that this part is view-only."""
    if can_edit():
        return True
    st.info("View only. Enter the team password in the sidebar to add or change data.")
    return False


def friendly_error(error: Exception) -> str:
    """Explain an error in plain words (same wording as the command-line program)."""
    text = str(error)
    if isinstance(error, sqlite3.IntegrityError):
        if "FOREIGN KEY" in text:
            return "Blocked: the ID does not exist, or other records still use this one."
        if "UNIQUE" in text:
            return "Blocked: that record already exists (duplicate)."
        return ("Blocked by a database rule (for example a value out of range, "
                "or a Closed incident without a resolved time).")
    if isinstance(error, ValueError):
        return f"Cannot continue: {error}"
    return f"Problem: {error}"


def run_action(action: Callable[[], str]) -> bool:
    """Run one saving step. Show its message, or a clear error. Return True on success."""
    try:
        message = action()
    except (ValueError, sqlite3.Error, OSError) as error:
        st.error(friendly_error(error))
        return False
    st.success(message)
    return True


def now_text() -> str:
    """The current Malaysian time as YYYY-MM-DD HH:MM."""
    return datetime.now().strftime(config.TIME_FORMAT)


def log_use(action: str, detail: str) -> None:
    """Record one analysis or export in the activity log."""
    with connect() as conn:
        operations.log_activity(conn, action, "", None, detail)


def csv_bytes(rows: list[dict]) -> bytes:
    """Rows as CSV bytes, with text made safe for spreadsheet programs."""
    if not rows:
        return b""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows({k: reports.safe_cell(v) for k, v in row.items()} for row in rows)
    return buffer.getvalue().encode("utf-8-sig")


def records(table: str) -> list[dict]:
    """All rows of one table."""
    with connect() as conn:
        return operations.list_records(conn, table)


def pick_station(label: str = "Station", key: str | None = None,
                 allow_all: bool = False) -> int | None:
    """Station drop-down. Returns a station ID, or None for all stations."""
    rows = records("stations")
    names = {r["station_id"]: f"{r['code']} - {r['name']}" for r in rows}
    options = ([None] if allow_all else []) + list(names)
    return st.selectbox(label, options, key=key,
                        format_func=lambda i: "All stations" if i is None else names[i])


def pick_observer(key: str | None = None) -> int | None:
    """Observer drop-down. Returns an observer ID."""
    names = {r["observer_id"]: r["name"] for r in records("observers")}
    return st.selectbox("Observer", list(names), key=key, format_func=lambda i: names[i])


def pick_participant(key: str | None = None) -> int | None:
    """Participant drop-down (anonymous codes only). Returns a participant ID."""
    names = {r["participant_id"]: f"{r['participant_code']} ({r['role']})"
             for r in records("participants")}
    return st.selectbox("Participant", list(names), key=key, format_func=lambda i: names[i])


def pick_parameter(key: str) -> str:
    """Parameter drop-down shown with readable labels."""
    return st.selectbox("Parameter", config.ANALYSIS_PARAMETERS, key=key,
                        format_func=lambda name: config.LABELS[name])


def when_input(label: str, key: str) -> str:
    """Date and time pickers joined as YYYY-MM-DD HH:MM (checked when saving)."""
    left, right = st.columns(2)
    day = left.date_input(f"{label} date", key=f"{key}_date")
    clock = right.time_input(f"{label} time", key=f"{key}_time")
    return f"{day.isoformat()} {clock.strftime('%H:%M')}"


def sidebar_filters() -> dict:
    """Station, date range and data source filters, shown in the sidebar."""
    st.sidebar.header("Filters")
    with st.sidebar:
        station_id = pick_station(key="filter_station", allow_all=True)
        start = end = None
        if st.checkbox("Limit to a date range", key="filter_dates"):
            start = st.date_input("From", value=date.today() - timedelta(days=180),
                                  key="filter_start").isoformat()
            end = st.date_input("To", key="filter_end").isoformat()
            if start > end:
                st.error("The start date is after the end date, so dates are ignored.")
                start = end = None
        source = st.selectbox("Data source", (None, *config.DATA_SOURCES), key="filter_source",
                              format_func=lambda s: "All sources" if s is None else s)
    return {"station_id": station_id, "start": start, "end": end, "source": source}


def rounded(value: float | None, places: int = 1) -> float | None:
    """Round a number for display, keeping None (no value) as it is."""
    return None if value is None else round(value, places)


def show_table(rows: list[dict], empty: str = "No matching records.") -> None:
    """Show rows as an interactive table, or a short note when there are none."""
    if rows:
        st.dataframe(rows, hide_index=True)
    else:
        st.info(empty)

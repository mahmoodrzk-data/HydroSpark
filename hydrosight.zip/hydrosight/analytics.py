"""Analytics layer: calculations on lists of dictionaries. No input, printing or SQL."""
import math
import statistics
from collections import Counter
from datetime import datetime

import config
import wqi

EPOCH = datetime(1970, 1, 1)


def is_outside(parameter: str, value: float) -> bool:
    """Return True if a value is outside the field screening limits."""
    low, high = config.SCREENING_LIMITS[parameter]
    return (low is not None and value < low) or (high is not None and value > high)


def failed_parameters(reading: dict) -> list[str]:
    """List the measured screening parameters of one reading that are outside limits."""
    return [name for name in config.SCREENING_LIMITS
            if reading.get(name) is not None and is_outside(name, reading[name])]


def flag_reading(reading: dict) -> str:
    """Field flag: WITHIN, WATCH (1 failure), CRITICAL (2 or more) or INCOMPLETE.

    A missing value is never treated as a pass.
    """
    failures = len(failed_parameters(reading))
    measured = sum(reading.get(name) is not None for name in config.SCREENING_LIMITS)
    if failures >= 2:
        return "CRITICAL"
    if failures == 1:
        return "WATCH"
    return "WITHIN" if measured == len(config.SCREENING_LIMITS) else "INCOMPLETE"


def add_wqi(readings: list[dict]) -> list[dict]:
    """Return copies of readings with wqi, wqi_class, wqi_status and flag added."""
    enriched = []
    for reading in readings:
        value = wqi.calculate_wqi(reading)
        enriched.append({
            **reading,
            "wqi": value,
            "wqi_class": wqi.wqi_class(value) if value is not None else None,
            "wqi_status": wqi.wqi_status(value) if value is not None else None,
            "flag": flag_reading(reading),
        })
    return enriched


def describe(readings: list[dict], parameter: str) -> dict:
    """Return count, missing, mean, median, sample SD, minimum and maximum."""
    values = [r[parameter] for r in readings if r.get(parameter) is not None]
    return {
        "n": len(values),
        "missing": len(readings) - len(values),
        "mean": statistics.fmean(values) if values else None,
        "median": statistics.median(values) if values else None,
        "sd": statistics.stdev(values) if len(values) >= 2 else None,
        "min": min(values) if values else None,
        "max": max(values) if values else None,
    }


def screening_score(readings: list[dict]) -> dict:
    """Percentage of available field checks within limits. NOT the DOE-WQI."""
    checks = passed = 0
    for reading in readings:
        for name in config.SCREENING_LIMITS:
            if reading.get(name) is not None:
                checks += 1
                passed += not is_outside(name, reading[name])
    score = None
    if len(readings) >= config.MIN_READINGS_FOR_SCORE and checks:
        score = 100 * passed / checks
    possible = len(readings) * len(config.SCREENING_LIMITS)
    return {"score": score, "passed": passed, "checks": checks,
            "coverage": 100 * checks / possible if possible else 0.0}


def wilson_interval(successes: int, trials: int, z: float = 1.96) -> tuple[float, float] | None:
    """Approximate 95% Wilson interval for a proportion (0 to 1)."""
    if trials <= 0:
        return None
    if not 0 <= successes <= trials:
        raise ValueError("successes must be between 0 and trials")
    p = successes / trials
    denominator = 1 + z * z / trials
    centre = (p + z * z / (2 * trials)) / denominator
    margin = z * math.sqrt(p * (1 - p) / trials + z * z / (4 * trials ** 2)) / denominator
    return max(0.0, centre - margin), min(1.0, centre + margin)


def exceedance(readings: list[dict], parameter: str) -> dict:
    """How often a screening parameter was outside its limit."""
    values = [r[parameter] for r in readings if r.get(parameter) is not None]
    count = sum(is_outside(parameter, v) for v in values)
    return {"outside": count, "n": len(values),
            "rate": count / len(values) if values else None,
            "interval": wilson_interval(count, len(values))}


def monthly_means(readings: list[dict], parameter: str) -> list[tuple[str, int, float]]:
    """Return (month, count, mean) for every month that has data."""
    groups: dict[str, list[float]] = {}
    for r in readings:
        if r.get(parameter) is not None:
            groups.setdefault(r["sampled_at"][:7], []).append(r[parameter])
    return [(month, len(v), statistics.fmean(v)) for month, v in sorted(groups.items())]


def moving_average(values: list[float], window: int = 3) -> list[float | None]:
    """Trailing average of the last `window` values; None until enough exist."""
    if window < 1:
        raise ValueError("window must be at least 1")
    return [statistics.fmean(values[i - window + 1:i + 1]) if i >= window - 1 else None
            for i in range(len(values))]


def mann_kendall(values: list[float]) -> dict:
    """Mann-Kendall test for a steady upward or downward trend.

    Uses the normal approximation with the tie correction. Values must be in time order.
    """
    n = len(values)
    s = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            difference = values[j] - values[i]
            s += (difference > 0) - (difference < 0)
    tie_groups = Counter(values).values()
    variance = (n * (n - 1) * (2 * n + 5)
                - sum(t * (t - 1) * (2 * t + 5) for t in tie_groups)) / 18
    if n < config.MIN_POINTS_FOR_TREND or variance <= 0:
        return {"n": n, "s": s, "variance": variance, "z": None, "p": None,
                "trend": "Too few values to test"}
    if s > 0:
        z = (s - 1) / math.sqrt(variance)
    elif s < 0:
        z = (s + 1) / math.sqrt(variance)
    else:
        z = 0.0
    p = 2 * (1 - statistics.NormalDist().cdf(abs(z)))
    if p >= config.TREND_ALPHA:
        trend = "No clear trend"
    elif z > 0:
        trend = "Increasing"
    else:
        trend = "Decreasing"
    return {"n": n, "s": s, "variance": variance, "z": z, "p": p, "trend": trend}


def to_days(moment: str) -> float:
    """Convert YYYY-MM-DD HH:MM to days since 1970 (time zone not involved)."""
    return (datetime.fromisoformat(moment) - EPOCH).total_seconds() / 86400


def sens_slope(times: list[str], values: list[float]) -> float | None:
    """Median slope of all pairs of points, expressed as change per 30 days."""
    days = [to_days(t) for t in times]
    slopes = [(values[j] - values[i]) / (days[j] - days[i])
              for i in range(len(days)) for j in range(i + 1, len(days))
              if days[j] != days[i]]
    return 30 * statistics.median(slopes) if slopes else None


def trend_summary(readings: list[dict], parameter: str) -> dict:
    """Mann-Kendall result and Sen's slope for ONE station's readings."""
    points = sorted((r["sampled_at"], r[parameter]) for r in readings
                    if r.get(parameter) is not None)
    times = [t for t, _ in points]
    values = [v for _, v in points]
    return {**mann_kendall(values), "slope_30d": sens_slope(times, values)}


def find_outliers(readings: list[dict], parameter: str) -> list[tuple[dict, float]]:
    """Unusual values by modified z-score (median and MAD). Use one station at a time."""
    rows = [r for r in readings if r.get(parameter) is not None]
    if len(rows) < 5:
        return []
    median = statistics.median(r[parameter] for r in rows)
    mad = statistics.median(abs(r[parameter] - median) for r in rows)
    if mad == 0:
        return []
    scored = [(r, 0.6745 * (r[parameter] - median) / mad) for r in rows]
    return [(r, z) for r, z in scored if abs(z) > config.OUTLIER_CUTOFF]


def incident_summary(incidents: list[dict]) -> dict:
    """Counts by type and station, plus every station tied for the most."""
    by_station = Counter(i["station_code"] for i in incidents)
    top = max(by_station.values(), default=0)
    return {
        "total": len(incidents),
        "by_type": Counter(i["incident_type"] for i in incidents),
        "by_station": by_station,
        "peak_sites": sorted(s for s, n in by_station.items() if n == top),
        "peak_count": top,
    }


def days_between(start: str, end: str) -> float:
    """Days from one YYYY-MM-DD HH:MM time to another."""
    return to_days(end) - to_days(start)


def response_times(incidents: list[dict], now: str) -> dict:
    """How quickly incidents are closed, and how many are overdue."""
    closed = [days_between(i["observed_at"], i["resolved_at"])
              for i in incidents if i["status"] == "Closed" and i["resolved_at"]]
    unresolved = [i for i in incidents if i["status"] != "Closed"]
    overdue = [i for i in unresolved
               if days_between(i["observed_at"], now) > config.BACKLOG_DAYS]
    return {
        "total": len(incidents),
        "closed": len(closed),
        "closure_rate": len(closed) / len(incidents) if incidents else None,
        "median_days": statistics.median(closed) if closed else None,
        "mean_days": statistics.fmean(closed) if closed else None,
        "unresolved": len(unresolved),
        "overdue": len(overdue),
    }


def rank_stations(stations: list[dict], readings: list[dict],
                  incidents: list[dict]) -> list[dict]:
    """Order stations for follow-up: lowest mean WQI first, then field screening.

    Stations without any WQI are listed after those with one.
    """
    table = []
    for s in stations:
        own = [r for r in readings if r["station_id"] == s["station_id"]]
        related = [i for i in incidents if i["station_id"] == s["station_id"]]
        values = [v for v in (wqi.calculate_wqi(r) for r in own) if v is not None]
        mean_wqi = statistics.fmean(values) if values else None
        screen = screening_score(own)
        table.append({
            "station": s["code"],
            "readings": len(own),
            "wqi_samples": len(values),
            "mean_wqi": mean_wqi,
            "wqi_class": wqi.wqi_class(mean_wqi) if mean_wqi is not None else None,
            "wqi_status": wqi.wqi_status(mean_wqi) if mean_wqi is not None else None,
            "screening_score": screen["score"],
            "coverage": screen["coverage"],
            "critical": sum(flag_reading(r) == "CRITICAL" for r in own),
            "incidents": len(related),
            "open_severity": sum(i["severity"] for i in related if i["status"] != "Closed"),
        })
    return sorted(table, key=lambda row: (
        row["mean_wqi"] is None, row["mean_wqi"] or 0,
        row["screening_score"] is None, row["screening_score"] or 0,
        -row["open_severity"], row["station"]))


def compare_periods(first: list[dict], second: list[dict], parameter: str) -> dict:
    """Difference in means between two periods. Does not show a cause."""
    a, b = describe(first, parameter), describe(second, parameter)
    change = None
    if a["mean"] is not None and b["mean"] is not None:
        change = b["mean"] - a["mean"]
    return {"first": a, "second": b, "change": change}

"""Validation layer. Each function returns a clean value or raises ValueError."""
import math
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path

import config

DATE_FORMAT = "%Y-%m-%d"


def required_text(text: str, max_length: int = 200) -> str:
    """Return trimmed text that is not blank and not too long."""
    cleaned = " ".join(text.split())
    if not cleaned:
        raise ValueError("This field cannot be blank.")
    if len(cleaned) > max_length:
        raise ValueError(f"Use at most {max_length} characters.")
    return cleaned


def optional_text(text: str) -> str:
    """Return trimmed text, or an empty string when left blank."""
    return required_text(text) if text.strip() else ""


def station_code(text: str) -> str:
    """Return an upper-case code made of letters, digits and hyphens."""
    code = required_text(text, 12).upper()
    if not all(ch.isascii() and (ch.isalnum() or ch == "-") for ch in code):
        raise ValueError("Use only letters, digits and hyphens.")
    return code


def participant_code(text: str) -> str:
    """Return an anonymous code such as P01 (P followed by 2 to 4 digits)."""
    code = text.strip().upper()
    digits = code[1:]
    if not (code.startswith("P") and digits.isascii() and digits.isdigit()
            and 2 <= len(digits) <= 4):
        raise ValueError("Use P followed by 2 to 4 digits, for example P01.")
    return code


def positive_int(text: str) -> int:
    """Convert text to a whole number above zero (used for record IDs)."""
    cleaned = text.strip()
    if not (cleaned.isascii() and cleaned.isdigit()) or len(cleaned) > 12 or int(cleaned) < 1:
        raise ValueError("Enter a positive whole number.")
    return int(cleaned)


def severity(text: str) -> int:
    """Return a severity of 1, 2 or 3."""
    if text.strip() not in ("1", "2", "3"):
        raise ValueError("Severity must be 1 (minor), 2 (moderate) or 3 (serious).")
    return int(text.strip())


def likert(text: str) -> int:
    """Return an agreement rating from 1 to 5."""
    if text.strip() not in ("1", "2", "3", "4", "5"):
        raise ValueError("Answer with a whole number from 1 to 5.")
    return int(text.strip())


def yes_no(text: str) -> bool:
    """Return True for y or yes, False for n or no."""
    answer = text.strip().lower()
    if answer in ("y", "yes"):
        return True
    if answer in ("n", "no"):
        return False
    raise ValueError("Answer y or n.")


def consent(text: str) -> int:
    """Return 1 when consent is given; otherwise the participant cannot be added."""
    if not yes_no(text):
        raise ValueError("A participant can only be added after giving consent.")
    return 1


def success(text: str) -> int:
    """Return 1 for a completed task and 0 for a failed one."""
    return int(yes_no(text))


def seconds(text: str) -> float:
    """Return a task time above 0 and at most 2 hours."""
    try:
        value = float(text.strip())
    except ValueError:
        raise ValueError("Enter the time in seconds, for example 95.5.") from None
    if not math.isfinite(value) or not 0 < value <= 7200:
        raise ValueError("Time must be more than 0 and at most 7200 seconds.")
    return value


def measurement(text: str, parameter: str) -> float | None:
    """Return a plausible number, or None when the value was not measured."""
    cleaned = text.strip()
    if not cleaned:
        return None
    try:
        value = float(cleaned)
    except ValueError:
        raise ValueError("Enter a number, or leave blank if not measured.") from None
    label, low, high = config.MEASURES[parameter]
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{label} must be from {low:g} to {high:g}.")
    return value


def required_measurement(text: str, parameter: str) -> float:
    """Like measurement(), but a value must be given."""
    value = measurement(text, parameter)
    if value is None:
        raise ValueError("A value is required here.")
    return value


def timestamp(text: str) -> str:
    """Return a real, non-future time written as YYYY-MM-DD HH:MM."""
    try:
        moment = datetime.strptime(text.strip(), config.TIME_FORMAT)
    except ValueError:
        raise ValueError("Use a real date and time: YYYY-MM-DD HH:MM.") from None
    if moment > datetime.now():
        raise ValueError("The time cannot be in the future.")
    return moment.strftime(config.TIME_FORMAT)


def resolved_time(text: str, observed_at: str) -> str:
    """Return a valid resolved time that is not before the observed time."""
    value = timestamp(text)
    if value < observed_at:
        raise ValueError("The resolved time cannot be before the observed time.")
    return value


def date_only(text: str) -> str:
    """Return a real date written as YYYY-MM-DD."""
    try:
        return datetime.strptime(text.strip(), DATE_FORMAT).strftime(DATE_FORMAT)
    except ValueError:
        raise ValueError("Use a real date: YYYY-MM-DD.") from None


def date_range(start: str | None, end: str | None) -> None:
    """Reject a range whose start is after its end."""
    if start and end and start > end:
        raise ValueError("The start date is after the end date.")


def choice(text: str, options: Sequence[str]) -> str:
    """Accept an option's menu number (starting at 1) and return the option."""
    cleaned = text.strip()
    for number, option in enumerate(options, start=1):
        if cleaned == str(number):
            return option
    raise ValueError(f"Choose a number from 1 to {len(options)}.")


def csv_path(text: str) -> Path:
    """Return the path of an existing .csv file."""
    path = Path(text.strip().strip('"'))
    if path.suffix.lower() != ".csv":
        raise ValueError("Give the path of a .csv file.")
    if not path.is_file():
        raise ValueError("No file was found at that path.")
    return path

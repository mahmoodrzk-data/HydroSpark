-- HydroSight database initialisation script. Safe to run repeatedly.
CREATE TABLE IF NOT EXISTS stations (
    station_id INTEGER PRIMARY KEY,
    code       TEXT NOT NULL UNIQUE,
    name       TEXT NOT NULL,
    river_name TEXT NOT NULL,
    area       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS observers (
    observer_id INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE,
    role        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS readings (
    reading_id          INTEGER PRIMARY KEY,
    station_id          INTEGER NOT NULL REFERENCES stations(station_id) ON DELETE RESTRICT,
    observer_id         INTEGER NOT NULL REFERENCES observers(observer_id) ON DELETE RESTRICT,
    sampled_at          TEXT NOT NULL,
    ph                  REAL CHECK (ph BETWEEN 0 AND 14),
    dissolved_oxygen    REAL CHECK (dissolved_oxygen BETWEEN 0 AND 20),
    turbidity           REAL CHECK (turbidity BETWEEN 0 AND 4000),
    temperature         REAL CHECK (temperature BETWEEN 0 AND 45),
    bod                 REAL CHECK (bod BETWEEN 0 AND 1000),
    cod                 REAL CHECK (cod BETWEEN 0 AND 5000),
    ammoniacal_nitrogen REAL CHECK (ammoniacal_nitrogen BETWEEN 0 AND 500),
    tss                 REAL CHECK (tss BETWEEN 0 AND 10000),
    data_source         TEXT NOT NULL CHECK (data_source IN ('synthetic', 'field', 'public')),
    notes               TEXT NOT NULL DEFAULT '',
    UNIQUE (station_id, sampled_at),
    CHECK (COALESCE(ph, dissolved_oxygen, turbidity, temperature,
                    bod, cod, ammoniacal_nitrogen, tss) IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS incidents (
    incident_id   INTEGER PRIMARY KEY,
    station_id    INTEGER NOT NULL REFERENCES stations(station_id) ON DELETE RESTRICT,
    observer_id   INTEGER NOT NULL REFERENCES observers(observer_id) ON DELETE RESTRICT,
    observed_at   TEXT NOT NULL,
    incident_type TEXT NOT NULL CHECK (incident_type IN
        ('Solid waste', 'Suspected chemical runoff', 'Suspected sewage', 'Silt or sediment', 'Other')),
    severity      INTEGER NOT NULL CHECK (severity BETWEEN 1 AND 3),
    status        TEXT NOT NULL CHECK (status IN ('Open', 'Under review', 'Closed')),
    description   TEXT NOT NULL,
    resolved_at   TEXT,
    data_source   TEXT NOT NULL CHECK (data_source IN ('synthetic', 'field', 'public')),
    UNIQUE (station_id, observed_at, incident_type),
    CHECK ((status = 'Closed') = (resolved_at IS NOT NULL)),
    CHECK (resolved_at IS NULL OR resolved_at >= observed_at)
);

CREATE TABLE IF NOT EXISTS activity_log (
    log_id     INTEGER PRIMARY KEY,
    logged_at  TEXT NOT NULL,
    action     TEXT NOT NULL CHECK (action IN
        ('create', 'update', 'delete', 'import', 'export', 'analysis')),
    table_name TEXT NOT NULL DEFAULT '',
    record_id  INTEGER,
    detail     TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS participants (
    participant_id   INTEGER PRIMARY KEY,
    participant_code TEXT NOT NULL UNIQUE,
    role             TEXT NOT NULL,
    consent          INTEGER NOT NULL CHECK (consent = 1)
);

CREATE TABLE IF NOT EXISTS sus_responses (
    response_id    INTEGER PRIMARY KEY,
    participant_id INTEGER NOT NULL UNIQUE
                   REFERENCES participants(participant_id) ON DELETE RESTRICT,
    submitted_at   TEXT NOT NULL,
    q1  INTEGER NOT NULL CHECK (q1 BETWEEN 1 AND 5),
    q2  INTEGER NOT NULL CHECK (q2 BETWEEN 1 AND 5),
    q3  INTEGER NOT NULL CHECK (q3 BETWEEN 1 AND 5),
    q4  INTEGER NOT NULL CHECK (q4 BETWEEN 1 AND 5),
    q5  INTEGER NOT NULL CHECK (q5 BETWEEN 1 AND 5),
    q6  INTEGER NOT NULL CHECK (q6 BETWEEN 1 AND 5),
    q7  INTEGER NOT NULL CHECK (q7 BETWEEN 1 AND 5),
    q8  INTEGER NOT NULL CHECK (q8 BETWEEN 1 AND 5),
    q9  INTEGER NOT NULL CHECK (q9 BETWEEN 1 AND 5),
    q10 INTEGER NOT NULL CHECK (q10 BETWEEN 1 AND 5),
    comment TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS task_trials (
    trial_id       INTEGER PRIMARY KEY,
    participant_id INTEGER NOT NULL REFERENCES participants(participant_id) ON DELETE RESTRICT,
    task_name      TEXT NOT NULL,
    method         TEXT NOT NULL CHECK (method IN ('manual', 'software')),
    seconds        REAL NOT NULL CHECK (seconds > 0 AND seconds <= 7200),
    success        INTEGER NOT NULL CHECK (success IN (0, 1)),
    recorded_at    TEXT NOT NULL,
    UNIQUE (participant_id, task_name, method)
);

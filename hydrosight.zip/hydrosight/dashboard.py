"""Build a self-contained HTML dashboard with SVG charts (standard library only)."""
import html
from datetime import datetime
from pathlib import Path

import analytics
import config
import reports

COLOURS: tuple[str, ...] = ("#1f6fb4", "#c0392b", "#2e8b57", "#8e44ad", "#d35400", "#596275")
CLASS_LINES: tuple[tuple[float, str], ...] = (
    (92.7, "Class I"), (76.5, "Class II"), (51.9, "Class III"), (31.0, "Class IV"))
STYLE = """body{font-family:Arial,sans-serif;margin:24px;color:#222;max-width:960px}
h1{margin-bottom:4px} .warn{background:#fff3cd;padding:8px 12px;border-radius:6px}
.kpis{display:flex;flex-wrap:wrap;gap:12px;margin:16px 0}
.kpi{border:1px solid #ddd;border-radius:8px;padding:10px 14px;min-width:120px}
.kpi .v{font-size:22px;font-weight:bold} .kpi .l{font-size:12px;color:#555}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border-bottom:1px solid #ddd;padding:6px;text-align:left} svg{width:100%;height:auto}
.t{font-size:11px;fill:#555}"""


def esc(value: object) -> str:
    """Make any value safe to place inside HTML."""
    return html.escape(str(value))


def kpi(label: str, value: str) -> str:
    """Return one summary tile."""
    return f'<div class="kpi"><div class="v">{esc(value)}</div><div class="l">{esc(label)}</div></div>'


def chart_x(index: int, count: int, left: float, width: float) -> float:
    """Horizontal position of the index-th month on the chart."""
    return left + (index * width / (count - 1) if count > 1 else width / 2)


def chart_y(value: float, top: float, height: float) -> float:
    """Vertical position of a 0-100 value on the chart."""
    return top + height * (1 - value / 100)


def wqi_chart(series: dict[str, list[tuple[str, float]]]) -> str:
    """SVG line chart of monthly mean WQI per station, with DOE class boundaries."""
    months = sorted({month for points in series.values() for month, _ in points})
    if not months:
        return "<p>No WQI values to chart yet.</p>"
    left, top, width, height = 50, 16, 500, 260
    parts = ['<svg viewBox="0 0 680 320" role="img" aria-label="Monthly mean WQI by station">']
    for value in (0, 25, 50, 75, 100):
        y = chart_y(value, top, height)
        parts.append(f'<line x1="{left}" x2="{left + width}" y1="{y:.1f}" y2="{y:.1f}" stroke="#eee"/>'
                     f'<text x="{left - 8}" y="{y + 4:.1f}" text-anchor="end" class="t">{value}</text>')
    for limit, label in CLASS_LINES:
        y = chart_y(limit, top, height)
        parts.append(f'<line x1="{left}" x2="{left + width}" y1="{y:.1f}" y2="{y:.1f}" '
                     f'stroke="#999" stroke-dasharray="4 4"/><text x="{left + width - 4}" '
                     f'y="{y - 4:.1f}" text-anchor="end" class="t">{label} from {limit}</text>')
    for index, month in enumerate(months):
        x = chart_x(index, len(months), left, width)
        parts.append(f'<text x="{x:.1f}" y="{top + height + 20}" text-anchor="middle" '
                     f'class="t">{esc(month)}</text>')
    for number, (name, points) in enumerate(sorted(series.items())):
        colour = COLOURS[number % len(COLOURS)]
        coords = [(chart_x(months.index(m), len(months), left, width), chart_y(v, top, height))
                  for m, v in points]
        path = " ".join(f"{x:.1f},{y:.1f}" for x, y in coords)
        parts.append(f'<polyline points="{path}" fill="none" stroke="{colour}" stroke-width="2"/>')
        parts += [f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3" fill="{colour}"/>' for x, y in coords]
        parts.append(f'<rect x="{left + width + 20}" y="{top + number * 20}" width="12" height="12" '
                     f'fill="{colour}"/><text x="{left + width + 38}" y="{top + number * 20 + 10}" '
                     f'class="t">{esc(name)}</text>')
    parts.append("</svg>")
    return "".join(parts)


def bar_chart(counts: dict[str, int]) -> str:
    """SVG horizontal bar chart, for example incidents by type."""
    if not counts:
        return "<p>No incidents recorded.</p>"
    largest = max(counts.values())
    rows = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    parts = [f'<svg viewBox="0 0 680 {30 * len(rows) + 10}" role="img" aria-label="Incidents by type">']
    for index, (label, count) in enumerate(rows):
        y = 6 + index * 30
        length = 400 * count / largest
        parts.append(f'<text x="190" y="{y + 15}" text-anchor="end" class="t">{esc(label)}</text>'
                     f'<rect x="200" y="{y}" width="{length:.1f}" height="20" fill="#1f6fb4"/>'
                     f'<text x="{206 + length:.1f}" y="{y + 15}" class="t">{count}</text>')
    parts.append("</svg>")
    return "".join(parts)


def build_dashboard(stations: list[dict], readings: list[dict], incidents: list[dict],
                    period: str, now: str | None = None) -> str:
    """Return a complete HTML page summarising water quality and incidents."""
    now = now or datetime.now().strftime(config.TIME_FORMAT)
    rows = analytics.add_wqi(readings)
    ranking = analytics.rank_stations(stations, readings, incidents)
    response = analytics.response_times(incidents, now)
    sources = sorted({r["data_source"] for r in readings + incidents})
    values = [r["wqi"] for r in rows if r["wqi"] is not None]
    series = {}
    for station in stations:
        own = [r for r in rows if r["station_id"] == station["station_id"]]
        months = analytics.monthly_means(own, "wqi")
        if months:
            series[station["code"]] = [(month, mean) for month, _, mean in months]
    table_rows = "".join(
        f"<tr><td>{esc(r['station'])}</td><td>{reports.number(r['mean_wqi'])}</td>"
        f"<td>{esc(r['wqi_class'] or '-')}</td><td>{esc(r['wqi_status'] or '-')}</td>"
        f"<td>{r['wqi_samples']}</td><td>{r['critical']}</td><td>{r['incidents']}</td>"
        f"<td>{r['open_severity']}</td></tr>" for r in ranking)
    warning = ('<p class="warn">Contains SYNTHETIC test data. Not real river measurements.</p>'
               if "synthetic" in sources else "")
    tiles = "".join([
        kpi("Stations", str(len(stations))),
        kpi("Readings", str(len(readings))),
        kpi("WQI samples", str(len(values))),
        kpi("Mean WQI", reports.number(sum(values) / len(values)) if values else "n/a"),
        kpi("Critical field flags", str(sum(r["flag"] == "CRITICAL" for r in rows))),
        kpi("Unresolved incidents", str(response["unresolved"])),
    ])
    counts = dict(analytics.incident_summary(incidents)["by_type"])
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>{esc(config.APP_NAME)} dashboard</title><style>{STYLE}</style></head><body>
<h1>{esc(config.APP_NAME)} river quality dashboard</h1>
<p>Period: {esc(period)} | Generated: {esc(now)} | Data sources: {esc(', '.join(sources) or 'none')}</p>
{warning}<div class="kpis">{tiles}</div>
<h2>Stations to check first (lowest mean WQI first)</h2>
<table><tr><th>Station</th><th>Mean WQI</th><th>Class</th><th>Status</th><th>WQI samples</th>
<th>Critical flags</th><th>Incidents</th><th>Open severity</th></tr>{table_rows}</table>
<h2>Monthly mean WQI</h2>{wqi_chart(series)}
<h2>Incidents by type</h2>{bar_chart(counts)}
<p class="t">WQI uses the DOE formula and needs laboratory values. Screening only: not proof of
safety, pollution source or legal breach.</p></body></html>"""


def save_dashboard(text: str, folder: Path = config.REPORT_DIR) -> Path:
    """Write the HTML page to a new file and return its path."""
    path = reports.new_path(folder, "dashboard", ".html")
    path.write_text(text, encoding="utf-8")
    return path

"""Application logic: Create, Read, Update and Delete, searches and the activity log."""
import sqlite3
from datetime import datetime

import config
import validation
from database import fetch_all

SUS_COLUMNS: tuple[str, ...] = tuple(f"q{number}" for number in range(1, 11))

# Only these table and column names are ever placed into SQL text.
# User values are always passed separately through ? placeholders.
TABLES: dict[str, tuple[str, tuple[str, ...]]] = {
    "stations": ("station_id", ("code", "name", "river_name", "area")),
    "observers": ("observer_id", ("name", "role")),
    "readings": ("reading_id", ("station_id", "observer_id", "sampled_at",
                 *config.MEASURES, "data_source", "notes")),
    "incidents": ("incident_id", ("station_id", "observer_id", "observed_at", "incident_type",
                  "severity", "status", "description", "resolved_at", "data_source")),
    "participants": ("participant_id", ("participant_code", "role", "consent")),
    "sus_responses": ("response_id", ("participant_id", "submitted_at", *SUS_COLUMNS, "comment")),
    "task_trials": ("trial_id", ("participant_id", "task_name", "method", "seconds",
                    "success", "recorded_at")),
}


def _check_table(table: str) -> None:
    """Reject an unknown table name."""
    if table not in TABLES:
        raise ValueError("Unknown table.")


def _check_fields(table: str, data: dict) -> None:
    """Reject unknown column names or an empty change."""
    _check_table(table)
    unknown = set(data) - set(TABLES[table][1])
    if unknown or not data:
        raise ValueError(f"Invalid fields: {sorted(unknown)}")


def log_activity(conn: sqlite3.Connection, action: str, table_name: str = "",
                 record_id: int | None = None, detail: str = "") -> None:
    """Record one use of the system in the activity log (the audit trail)."""
    if action not in config.ACTIONS:
        raise ValueError("Unknown action.")
    conn.execute(
        "INSERT INTO activity_log (logged_at, action, table_name, record_id, detail) "
        "VALUES (?, ?, ?, ?, ?)",
        (datetime.now().strftime(config.TIME_FORMAT), action, table_name, record_id, detail))


def create_record(conn: sqlite3.Connection, table: str, data: dict, log: bool = True) -> int:
    """Insert one row, log it, and return its new ID."""
    _check_fields(table, data)
    columns = ", ".join(data)
    marks = ", ".join("?" for _ in data)
    cursor = conn.execute(
        f"INSERT INTO {table} ({columns}) VALUES ({marks})", tuple(data.values()))
    if log:
        log_activity(conn, "create", table, cursor.lastrowid)
    return cursor.lastrowid


def get_record(conn: sqlite3.Connection, table: str, record_id: int) -> dict | None:
    """Return one row by primary key, or None if it does not exist."""
    _check_table(table)
    key = TABLES[table][0]
    rows = fetch_all(conn, f"SELECT * FROM {table} WHERE {key} = ?", (record_id,))
    return rows[0] if rows else None


def list_records(conn: sqlite3.Connection, table: str) -> list[dict]:
    """Return every row in ID order."""
    _check_table(table)
    return fetch_all(conn, f"SELECT * FROM {table} ORDER BY {TABLES[table][0]}")


def update_record(conn: sqlite3.Connection, table: str, record_id: int, changes: dict,
                  log: bool = True) -> bool:
    """Change selected fields. Return True if a row was changed."""
    _check_fields(table, changes)
    assignments = ", ".join(f"{column} = ?" for column in changes)
    key = TABLES[table][0]
    cursor = conn.execute(
        f"UPDATE {table} SET {assignments} WHERE {key} = ?", (*changes.values(), record_id))
    changed = cursor.rowcount == 1
    if changed and log:
        log_activity(conn, "update", table, record_id, ", ".join(changes))
    return changed


def delete_record(conn: sqlite3.Connection, table: str, record_id: int, log: bool = True) -> bool:
    """Delete one row. Rows still used by other tables are protected by the database."""
    _check_table(table)
    key = TABLES[table][0]
    cursor = conn.execute(f"DELETE FROM {table} WHERE {key} = ?", (record_id,))
    deleted = cursor.rowcount == 1
    if deleted and log:
        log_activity(conn, "delete", table, record_id)
    return deleted


def _filters(time_column: str, station_id: int | None, start: str | None, end: str | None,
             source: str | None) -> tuple[list[str], list]:
    """Build the WHERE parts shared by reading and incident searches."""
    validation.date_range(start, end)
    clauses: list[str] = []
    params: list = []
    if station_id is not None:
        clauses.append("t.station_id = ?")
        params.append(station_id)
    if start:
        clauses.append(f"substr(t.{time_column}, 1, 10) >= ?")
        params.append(start)
    if end:
        clauses.append(f"substr(t.{time_column}, 1, 10) <= ?")
        params.append(end)
    if source in config.DATA_SOURCES:
        clauses.append("t.data_source = ?")
        params.append(source)
    return clauses, params


def _where(clauses: list[str]) -> str:
    """Join conditions into a WHERE clause, or return nothing."""
    return " WHERE " + " AND ".join(clauses) if clauses else ""


def search_readings(conn: sqlite3.Connection, station_id: int | None = None,
                    start: str | None = None, end: str | None = None,
                    source: str | None = None) -> list[dict]:
    """Return readings, joined to station codes, matching the filters."""
    clauses, params = _filters("sampled_at", station_id, start, end, source)
    return fetch_all(conn,
        "SELECT t.*, s.code AS station_code FROM readings AS t "
        "JOIN stations AS s ON s.station_id = t.station_id" + _where(clauses) +
        " ORDER BY t.sampled_at, s.code", tuple(params))


def search_incidents(conn: sqlite3.Connection, station_id: int | None = None,
                     start: str | None = None, end: str | None = None,
                     source: str | None = None, incident_type: str | None = None,
                     status: str | None = None, keyword: str | None = None) -> list[dict]:
    """Return incidents, joined to station codes, matching the filters."""
    clauses, params = _filters("observed_at", station_id, start, end, source)
    if incident_type in config.INCIDENT_TYPES:
        clauses.append("t.incident_type = ?")
        params.append(incident_type)
    if status in config.STATUSES:
        clauses.append("t.status = ?")
        params.append(status)
    if keyword:
        clauses.append("instr(lower(t.description), lower(?)) > 0")
        params.append(keyword)
    return fetch_all(conn,
        "SELECT t.*, s.code AS station_code FROM incidents AS t "
        "JOIN stations AS s ON s.station_id = t.station_id" + _where(clauses) +
        " ORDER BY t.observed_at, s.code", tuple(params))


def list_activity(conn: sqlite3.Connection, start: str | None = None,
                  end: str | None = None) -> list[dict]:
    """Return activity log entries between two dates (inclusive)."""
    validation.date_range(start, end)
    clauses: list[str] = []
    params: list = []
    if start:
        clauses.append("substr(logged_at, 1, 10) >= ?")
        params.append(start)
    if end:
        clauses.append("substr(logged_at, 1, 10) <= ?")
        params.append(end)
    return fetch_all(conn, "SELECT * FROM activity_log" + _where(clauses) +
                     " ORDER BY log_id", tuple(params))


def list_sus(conn: sqlite3.Connection) -> list[dict]:
    """Return SUS responses with the participant's code and role."""
    return fetch_all(conn,
        "SELECT r.*, p.participant_code, p.role FROM sus_responses AS r "
        "JOIN participants AS p ON p.participant_id = r.participant_id ORDER BY r.response_id")


def list_trials(conn: sqlite3.Connection) -> list[dict]:
    """Return task trials with the participant's code."""
    return fetch_all(conn,
        "SELECT t.*, p.participant_code FROM task_trials AS t "
        "JOIN participants AS p ON p.participant_id = t.participant_id ORDER BY t.trial_id")

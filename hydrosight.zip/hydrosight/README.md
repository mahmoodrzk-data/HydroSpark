# HydroSight: River Quality and Pollution Analytics System

SIM2011 Structured Programming group project (Option A), Universiti Malaya.
One set of Python modules with two front ends:
- a menu-driven command-line program (`main.py`), standard library only, for IDLE and the assignment demo;
- a Streamlit web app (`Home.py` + `pages/`), for the public prototype planned for Sungai Way, Petaling Jaya.

Both use the same database file, the same validation rules and the same calculations, so they give the same answers.
Needs Python 3.10 or newer. Tested on Python 3.11, 3.12 and 3.13 (Linux). Test it on your own computers.

## Run the command-line program
1. `python seed_data.py`  (once: creates the database and the SYNTHETIC demo data)
2. `python main.py`
In IDLE: open the file, then press F5.

## Run the web app on your laptop
1. `pip install -r requirements.txt`  (installs Streamlit and pandas)
2. `streamlit run Home.py`  (opens in your browser; loads the demo data if the database is empty)

## Put the web app online (Streamlit Community Cloud, free)
1. Upload this folder to a GitHub repository. A private repository is safer.
   The `.gitignore` file keeps the database file and secrets out of GitHub.
2. Sign in at share.streamlit.io with GitHub, click "Create app", choose the repository,
   and set the main file path to `Home.py`.
3. In "Advanced settings", paste this into Secrets (choose your own long password):
   `EDIT_PASSWORD = "your-team-password"`
   Visitors can view; only people with the password can add, change or delete data.
4. Deploy. Apps with no visitors for 12 hours go to sleep; anyone can wake one up by opening it.

## Keep the online data safe (important)
Streamlit Community Cloud deletes local files, including the database, when the app restarts.
After every data-entry session:
1. Open the "Data and backup" page and download the full backup (a zip of CSV files).
2. Unzip it and upload the CSV files into `data/live` in your GitHub repository.
When the app starts with an empty database, it loads `data/live`. If that folder has no
`stations.csv`, it loads the SYNTHETIC demo data. Before real monitoring starts, use
"Data and backup" > Reset > "An empty database", then add your real stations.

## Test
- `python -m unittest -v tests.test_app`  (41 tests: command-line program and core modules)
- `python -m unittest -v tests.test_web`  (data backup tests; page tests run only if Streamlit is installed)

## Main features
- Records for stations, observers, water readings and pollution incidents (full CRUD)
- Malaysia's DOE Water Quality Index (WQI) with class and status
- Field screening flags, station ranking, Mann-Kendall trend test, Sen's slope, outlier check
- CSV import with row-by-row validation; CSV, text and HTML dashboard exports
- Evaluation module: activity log, System Usability Scale, time-on-task comparison
- Web app: same features in the browser, team password for editing, full backup and restore

## Files
| File | Job |
|---|---|
| main.py | Command-line menus and program flow |
| ui.py | Command-line prompts and table display |
| Home.py | Web app home page (KPIs, ranking, charts) |
| pages/1_Record_data.py ... pages/6_Data_and_backup.py | Web app pages |
| web_common.py | Shared web helpers: start-up, login, filters, messages |
| data_store.py | Back up and restore every table as CSV files |
| validation.py | Checks typed and imported input |
| operations.py | CRUD, searches, activity log |
| database.py | Connection and set-up |
| schema.sql | Database initialisation script (8 tables) |
| wqi.py | DOE Water Quality Index |
| analytics.py | Statistics, trend test, ranking |
| impact.py | Usability and impact measures |
| importer.py | CSV import |
| reports.py | CSV and text reports |
| dashboard.py | HTML dashboard with SVG charts |
| config.py | Settings, limits, questionnaire |
| seed_data.py | Synthetic seed dataset (CSV copies in data/seed) |
| requirements.txt | Packages for the web app |
| .streamlit/config.toml | Web app settings (5 MB upload limit, colour) |
| data/live/ | Saved copy of the real data, loaded when the web app starts |
| tests/test_app.py, tests/test_web.py | Automated tests |

## Reset the demo data (command-line program)
Close the program, back up `data/hydrosight.db` if it holds real evaluation data, delete it,
then run `python seed_data.py`. Deleting the file erases everything in it.

All seed data are invented. Field screening limits and WQI formulas are documented in the report.

"""Database layer: connections, set-up and a query helper."""
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

import config


@contextmanager
def open_db(path: Path | str = config.DB_PATH) -> Iterator[sqlite3.Connection]:
    """Open a connection; commit on success, undo on error, always close."""
    conn = sqlite3.connect(path)
    try:
        conn.row_factory = sqlite3.Row            # access columns by name
        conn.execute("PRAGMA foreign_keys = ON")  # SQLite leaves this off by default
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path: Path | str = config.DB_PATH) -> None:
    """Create the data folder and any missing tables."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    script = config.SCHEMA_PATH.read_text(encoding="utf-8")
    with open_db(path) as conn:
        conn.executescript(script)


def fetch_all(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict]:
    """Run a SELECT and return each row as a dictionary."""
    return [dict(row) for row in conn.execute(sql, params).fetchall()]

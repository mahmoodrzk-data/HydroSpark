"""Input and display helpers for the command line interface."""
from collections.abc import Callable, Sequence

import validation


class Cancelled(Exception):
    """Raised when the user types q to leave the current task."""


def ask(prompt: str, check: Callable[[str], object]) -> object:
    """Repeat a question until check() accepts the answer."""
    while True:
        text = input(f"{prompt} (q = cancel): ")
        if text.strip().lower() == "q":
            raise Cancelled
        try:
            return check(text)
        except ValueError as error:
            print(f"  Invalid: {error}")


def ask_optional(prompt: str, check: Callable[[str], object]) -> object | None:
    """Like ask(), but a blank answer returns None."""
    return ask(f"{prompt}, blank = skip",
               lambda text: check(text) if text.strip() else None)


def ask_choice(title: str, options: Sequence[str]) -> str:
    """Show numbered options and return the chosen one."""
    show_options(title, options)
    return ask("Number", lambda text: validation.choice(text, options))


def ask_yes_no(prompt: str) -> bool:
    """Ask a y/n question."""
    return ask(f"{prompt} (y/n)", validation.yes_no)


def show_options(title: str, options: Sequence[str]) -> None:
    """Print a numbered list."""
    print(f"\n{title}")
    for number, option in enumerate(options, start=1):
        print(f"  {number}. {option}")


def show_table(rows: list[dict]) -> None:
    """Print dictionaries as an aligned text table."""
    if not rows:
        print("No matching records.")
        return
    headers = list(rows[0])
    cells = [["" if row[h] is None else str(row[h])[:40] for h in headers] for row in rows]
    widths = [max(len(h), *(len(line[i]) for line in cells)) for i, h in enumerate(headers)]
    print(" | ".join(h.ljust(w) for h, w in zip(headers, widths)))
    print("-+-".join("-" * w for w in widths))
    for line in cells:
        print(" | ".join(c.ljust(w) for c, w in zip(line, widths)))
    print(f"({len(rows)} record(s))")

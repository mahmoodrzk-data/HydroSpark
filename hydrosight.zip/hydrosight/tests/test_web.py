"""Tests for the web app's data storage, and (if Streamlit is installed) every web page.

Run from the project folder:  python -m unittest -v tests.test_web
"""
import importlib.util
import io
import os
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

import data_store
import database
import operations
import seed_data


def build_database(folder: Path) -> Path:
    """A database with the seed data plus one participant, SUS response, trial and log entry."""
    path = folder / "test.db"
    database.init_db(path)
    with database.open_db(path) as conn:
        seed_data.load(conn, seed_data.build_rows())
        person = operations.create_record(
            conn, "participants", {"participant_code": "P01", "role": "Student", "consent": 1})
        operations.create_record(conn, "sus_responses", {
            "participant_id": person, "submitted_at": "2026-11-25 10:00",
            **{f"q{n}": 3 for n in range(1, 11)}, "comment": ""})
        operations.create_record(conn, "task_trials", {
            "participant_id": person, "task_name": "T1 Record a new water reading",
            "method": "manual", "seconds": 95.5, "success": 1, "recorded_at": "2026-11-25 10:05"})
    return path


def everything(path: Path) -> dict:
    """Every row of every table, for comparing two databases."""
    with database.open_db(path) as conn:
        return {table: database.fetch_all(conn, f"SELECT * FROM {table} ORDER BY rowid")
                for table in data_store.TABLE_ORDER}


class DataStoreTests(unittest.TestCase):
    def setUp(self):
        self.folder = Path(tempfile.mkdtemp())
        self.path = build_database(self.folder)

    def tearDown(self):
        shutil.rmtree(self.folder)

    def fresh(self, name: str) -> Path:
        path = self.folder / name
        database.init_db(path)
        return path

    def test_W01_zip_backup_round_trip(self):
        with database.open_db(self.path) as conn:
            backup = data_store.backup_zip(conn)
        copy = self.fresh("copy.db")
        with database.open_db(copy) as conn:
            counts = data_store.replace_all(conn, data_store.read_zip(backup))
        self.assertEqual(counts["readings"], 96)
        self.assertEqual(everything(copy), everything(self.path))

    def test_W02_folder_round_trip(self):
        live = self.folder / "live"
        with database.open_db(self.path) as conn:
            self.assertEqual(len(data_store.write_folder(conn, live)), 8)
        copy = self.fresh("copy.db")
        with database.open_db(copy) as conn:
            data_store.replace_all(conn, data_store.read_folder(live))
        self.assertEqual(everything(copy), everything(self.path))
        self.assertEqual(data_store.read_folder(self.folder / "missing"), {})

    def test_W03_bad_backup_changes_nothing(self):
        with database.open_db(self.path) as conn:
            tables = data_store.read_zip(data_store.backup_zip(conn))
        before = everything(self.path)
        broken_rows = [dict(tables["readings"][0], ph="20")]          # outside the database rule
        unknown_column = [dict(tables["stations"][0], colour="blue")]
        bad_number = [dict(tables["readings"][0], station_id="1.5")]
        for change in ({"readings": broken_rows}, {"stations": unknown_column},
                       {"readings": bad_number}):
            with self.subTest(change=list(change)):
                with self.assertRaises(ValueError):
                    with database.open_db(self.path) as conn:
                        data_store.replace_all(conn, {**tables, **change})
                self.assertEqual(everything(self.path), before)
        with self.assertRaises(ValueError):
            with database.open_db(self.path) as conn:
                data_store.replace_all(conn, {"readings": []})          # no stations.csv
        self.assertEqual(everything(self.path), before)

    def test_W04_zip_checks(self):
        with self.assertRaises(ValueError):
            data_store.read_zip(b"not a zip file")
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:          # files inside a folder are found
            archive.writestr("backup/stations.csv", "station_id,code,name,river_name,area\n"
                                                    "1,SW-01,Upstream,Sungai Way,SS9A\n")
            archive.writestr("notes.txt", "ignored")
        tables = data_store.read_zip(buffer.getvalue())
        self.assertEqual(list(tables), ["stations"])
        self.assertEqual(tables["stations"][0]["code"], "SW-01")

    def test_W05_blank_cells_and_types(self):
        column = {"name": "x", "type": "REAL", "notnull": False}
        self.assertIsNone(data_store.convert("", column))
        self.assertEqual(data_store.convert("7.25", column), 7.25)
        with self.assertRaises(ValueError):
            data_store.convert("inf", column)
        text = {"name": "notes", "type": "TEXT", "notnull": True}
        self.assertEqual(data_store.convert("", text), "")
        whole = {"name": "severity", "type": "INTEGER", "notnull": True}
        self.assertEqual(data_store.convert("2.0", whole), 2)

    def test_W06_clear_and_counts(self):
        with database.open_db(self.path) as conn:
            self.assertFalse(data_store.is_empty(conn))
            data_store.clear_all(conn)
            self.assertTrue(data_store.is_empty(conn))
            self.assertEqual(set(data_store.row_counts(conn).values()), {0})


@unittest.skipUnless(importlib.util.find_spec("streamlit"), "Streamlit is not installed")
class PageTests(unittest.TestCase):
    """Run every page with Streamlit's own test tool, on a temporary database."""

    @classmethod
    def setUpClass(cls):
        cls.folder = Path(tempfile.mkdtemp())
        os.environ["HYDROSIGHT_DB"] = str(cls.folder / "web.db")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.folder)

    def test_W07_every_page_runs(self):
        from streamlit.testing.v1 import AppTest
        pages = ["Home.py", *sorted(f"pages/{p.name}" for p in (PROJECT / "pages").glob("*.py"))]
        for page in pages:
            with self.subTest(page=page):
                app = AppTest.from_file(str(PROJECT / page), default_timeout=60)
                app.run()
                self.assertFalse(app.exception, f"{page}: {app.exception}")


if __name__ == "__main__":
    unittest.main()

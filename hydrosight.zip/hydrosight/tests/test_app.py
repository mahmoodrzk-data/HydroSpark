"""Automated tests. Run from the project folder:  python -m unittest -v tests.test_app"""
import csv
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

import analytics
import dashboard
import database
import impact
import importer
import operations
import reports
import seed_data
import validation
import wqi


def reading(ph=7.0, oxygen=6.0, turbidity=10.0, at="2026-06-01 09:00", station=1, **lab):
    """Make one reading dictionary for tests."""
    row = {"station_id": station, "observer_id": 1, "sampled_at": at, "ph": ph,
           "dissolved_oxygen": oxygen, "turbidity": turbidity, "temperature": None,
           "bod": None, "cod": None, "ammoniacal_nitrogen": None, "tss": None,
           "data_source": "synthetic", "notes": ""}
    row.update(lab)
    return row


class ValidationTests(unittest.TestCase):
    def test_T01_measurement_boundaries(self):
        self.assertEqual(validation.measurement("0", "ph"), 0)
        self.assertEqual(validation.measurement("14", "ph"), 14)
        for bad in ("-0.01", "14.01", "nan", "inf", "abc"):
            with self.assertRaises(ValueError, msg=bad):
                validation.measurement(bad, "ph")
        self.assertIsNone(validation.measurement("  ", "tss"))
        with self.assertRaises(ValueError):
            validation.required_measurement("", "bod")

    def test_T02_dates_and_resolved_time(self):
        self.assertEqual(validation.timestamp("2026-06-01 09:00"), "2026-06-01 09:00")
        for bad in ("2026-02-30 10:00", "01-06-2026 09:00", "2999-01-01 00:00", ""):
            with self.assertRaises(ValueError, msg=bad):
                validation.timestamp(bad)
        with self.assertRaises(ValueError):
            validation.date_range("2026-07-01", "2026-06-01")
        with self.assertRaises(ValueError):
            validation.resolved_time("2026-06-01 08:00", "2026-06-01 09:00")
        self.assertEqual(validation.resolved_time("2026-06-01 09:00", "2026-06-01 09:00"),
                         "2026-06-01 09:00")

    def test_T03_menus_ids_and_text(self):
        self.assertEqual(validation.choice("2", ("a", "b")), "b")
        for bad in ("0", "3", "x", ""):
            with self.assertRaises(ValueError):
                validation.choice(bad, ("a", "b"))
        for bad in ("0", "-1", "1.5", "²", "9" * 30):
            with self.assertRaises(ValueError, msg=bad):
                validation.positive_int(bad)
        with self.assertRaises(ValueError):
            validation.required_text("   ")
        with self.assertRaises(ValueError):
            validation.station_code("A B!")

    def test_T04_evaluation_inputs(self):
        self.assertEqual(validation.participant_code("p07"), "P07")
        for bad in ("P1", "X01", "P12345", "P0a"):
            with self.assertRaises(ValueError, msg=bad):
                validation.participant_code(bad)
        self.assertEqual(validation.likert("5"), 5)
        for bad in ("0", "6", "2.5"):
            with self.assertRaises(ValueError):
                validation.likert(bad)
        self.assertEqual(validation.consent("Y"), 1)
        with self.assertRaises(ValueError):
            validation.consent("n")
        self.assertEqual(validation.success("no"), 0)
        with self.assertRaises(ValueError):
            validation.seconds("0")


class WqiTests(unittest.TestCase):
    def test_T05_sub_indices_by_hand(self):
        cases = [
            (wqi.si_do, 50, -0.395 + 75 - 25), (wqi.si_do, 8, 0), (wqi.si_do, 92, 100),
            (wqi.si_bod, 5, 79.25), (wqi.si_bod, 10, 108 * 0.576949810 - 1),
            (wqi.si_cod, 20, 72.5), (wqi.si_an, 0.3, 69.0), (wqi.si_an, 4, 0),
            (wqi.si_ss, 100, 97.5 * 0.508648 + 5), (wqi.si_ss, 1000, 0),
            (wqi.si_ph, 7, -181 + 576.8 - 296.45), (wqi.si_ph, 6, -242 + 573 - 240.12),
        ]
        for function, x, expected in cases:
            with self.subTest(function=function.__name__, x=x):
                self.assertAlmostEqual(function(x), expected, places=2)

    def test_T06_oxygen_solubility_matches_published_table(self):
        for temperature, table_value in ((20, 9.08), (28, 7.81), (30, 7.54)):
            self.assertAlmostEqual(wqi.saturation_do(temperature), table_value, delta=0.02)
        self.assertAlmostEqual(wqi.do_percent(7.81, 28), 100, delta=0.3)

    def test_T07_wqi_value_class_and_status(self):
        sample = {"dissolved_oxygen": 7.81, "temperature": 28, "bod": 5, "cod": 20,
                  "ammoniacal_nitrogen": 0.3, "tss": 100, "ph": 7}
        parts = wqi.sub_indices(sample)
        expected = (0.22 * parts["do"] + 0.19 * 79.25 + 0.16 * 72.5 + 0.15 * 69.0
                    + 0.16 * parts["ss"] + 0.12 * parts["ph"])
        self.assertAlmostEqual(wqi.calculate_wqi(sample), expected)
        self.assertEqual([wqi.wqi_class(v) for v in (92.71, 92.7, 76.5, 51.9, 31.0, 30.99)],
                         ["I", "II", "II", "III", "IV", "V"])
        self.assertEqual([wqi.wqi_status(v) for v in (81, 80.9, 60, 59.9)],
                         ["Clean", "Slightly polluted", "Slightly polluted", "Polluted"])

    def test_T08_missing_values_and_limits(self):
        self.assertIsNone(wqi.calculate_wqi(reading()))
        self.assertEqual(wqi.si_ss(900), 0.0)     # formula is negative here; kept at 0
        self.assertEqual(wqi.si_bod(0), 100.0)    # formula gives 100.4; kept at 100


class AnalyticsTests(unittest.TestCase):
    def test_T09_flags(self):
        self.assertEqual(analytics.flag_reading(reading(6.0, 5.0, 50.0)), "WITHIN")
        self.assertEqual(analytics.flag_reading(reading(5.99, 5.0, 50.0)), "WATCH")
        self.assertEqual(analytics.flag_reading(reading(7, 4.99, 50.01)), "CRITICAL")
        self.assertEqual(analytics.flag_reading(reading(7, None, 10)), "INCOMPLETE")

    def test_T10_statistics_and_score(self):
        rows = [reading(ph=v) for v in (6.0, 7.0, 8.0)] + [reading(ph=None)]
        result = analytics.describe(rows, "ph")
        self.assertEqual((result["n"], result["missing"]), (3, 1))
        self.assertAlmostEqual(result["sd"], 1.0)
        score = analytics.screening_score([reading(), reading(oxygen=4), reading(turbidity=60)])
        self.assertAlmostEqual(score["score"], 100 * 7 / 9)

    def test_T11_wilson_and_moving_average(self):
        low, high = analytics.wilson_interval(5, 10)
        self.assertAlmostEqual(low, 0.2366, places=4)
        self.assertAlmostEqual(high, 0.7634, places=4)
        self.assertIsNone(analytics.wilson_interval(0, 0))
        self.assertEqual(analytics.moving_average([1, 2, 3, 4]), [None, None, 2, 3])

    def test_T12_mann_kendall(self):
        result = analytics.mann_kendall(list(range(1, 11)))
        self.assertEqual((result["s"], result["variance"]), (45, 125))
        self.assertAlmostEqual(result["z"], 44 / 125 ** 0.5)
        self.assertLess(result["p"], 0.001)
        self.assertEqual(result["trend"], "Increasing")
        ties = analytics.mann_kendall([1, 2, 2, 3, 4, 5, 6, 7, 8, 9])
        self.assertEqual(ties["variance"], 124)
        self.assertEqual(analytics.mann_kendall([5, 1, 4, 2, 3, 3, 2, 4, 1, 5])["trend"],
                         "No clear trend")
        self.assertIsNone(analytics.mann_kendall([1, 2, 3])["p"])

    def test_T13_sens_slope(self):
        times = ["2026-06-01 09:00", "2026-07-01 09:00", "2026-07-31 09:00"]
        self.assertAlmostEqual(analytics.sens_slope(times, [4.0, 5.0, 6.0]), 1.0)
        self.assertIsNone(analytics.sens_slope(times[:1], [4.0]))

    def test_T14_outliers(self):
        rows = [reading(turbidity=v) for v in (10, 11, 12, 13, 100)]
        found = analytics.find_outliers(rows, "turbidity")
        self.assertEqual([r["turbidity"] for r, _ in found], [100])
        self.assertAlmostEqual(found[0][1], 0.6745 * 88)
        self.assertEqual(analytics.find_outliers([reading()] * 6, "turbidity"), [])

    def test_T15_incidents_and_response_times(self):
        rows = [{"station_code": c, "incident_type": "Other"} for c in ("A", "B")]
        self.assertEqual(analytics.incident_summary(rows)["peak_sites"], ["A", "B"])
        incidents = [
            {"observed_at": "2026-06-01 10:00", "resolved_at": "2026-06-05 10:00",
             "status": "Closed"},
            {"observed_at": "2026-06-01 10:00", "resolved_at": None, "status": "Open"}]
        result = analytics.response_times(incidents, "2026-06-20 10:00")
        self.assertEqual((result["closed"], result["median_days"], result["overdue"]), (1, 4, 1))
        self.assertEqual(result["closure_rate"], 0.5)

    def test_T16_ranking_and_comparison(self):
        stations = [{"station_id": 1, "code": "A"}, {"station_id": 2, "code": "B"}]
        lab = {"temperature": 28, "bod": 2, "cod": 15, "ammoniacal_nitrogen": 0.2, "tss": 20}
        dirty = {"temperature": 28, "bod": 20, "cod": 90, "ammoniacal_nitrogen": 3, "tss": 200}
        readings = [reading(station=1, **lab), reading(station=2, oxygen=3, **dirty)]
        order = [row["station"] for row in analytics.rank_stations(stations, readings, [])]
        self.assertEqual(order, ["B", "A"])
        change = analytics.compare_periods([reading(oxygen=4)], [reading(oxygen=6)],
                                           "dissolved_oxygen")["change"]
        self.assertEqual(change, 2)


class ImpactTests(unittest.TestCase):
    EXAMPLE = {"q1": 4, "q2": 2, "q3": 5, "q4": 1, "q5": 3,
               "q6": 3, "q7": 4, "q8": 1, "q9": 3, "q10": 1}

    def test_T17_sus_score_published_example(self):
        self.assertEqual(impact.sus_score(self.EXAMPLE), 77.5)
        self.assertEqual(impact.sus_score({f"q{n}": 5 if n % 2 else 1 for n in range(1, 11)}), 100)
        with self.assertRaises(ValueError):
            impact.sus_score({**self.EXAMPLE, "q1": 6})

    def test_T18_sus_summary(self):
        low = {f"q{n}": 3 for n in range(1, 11)}            # score 50
        result = impact.sus_summary([self.EXAMPLE, low])
        self.assertEqual((result["n"], result["mean"], result["share_at_benchmark"]),
                         (2, 63.75, 0.5))
        self.assertIsNone(impact.sus_summary([])["mean"])

    def test_T19_time_on_task(self):
        task = "T1 Record a new water reading"
        trials = [
            {"participant_id": 1, "task_name": task, "method": "manual", "seconds": 120, "success": 1},
            {"participant_id": 1, "task_name": task, "method": "software", "seconds": 30, "success": 1},
            {"participant_id": 2, "task_name": task, "method": "manual", "seconds": 100, "success": 0},
            {"participant_id": 2, "task_name": task, "method": "software", "seconds": 50, "success": 1}]
        first = impact.task_comparison(trials)[0]
        self.assertAlmostEqual(first["time_saved_pct"], 100 * 70 / 110)
        self.assertEqual((first["manual_success"], first["software_success"]), (0.5, 1))
        paired = impact.paired_savings(trials)
        self.assertEqual((paired["pairs"], paired["median_saving_pct"], paired["share_faster"]),
                         (2, 62.5, 1.0))

    def test_T20_usage_and_data_quality(self):
        log = [{"logged_at": "2026-11-01 10:00", "action": "create", "table_name": "readings"},
               {"logged_at": "2026-11-02 10:00", "action": "export", "table_name": ""}]
        usage = impact.usage_summary(log)
        self.assertEqual((usage["events"], usage["active_days"],
                          usage["created_by_table"]["readings"]), (2, 2, 1))
        lab = {"temperature": 28, "bod": 2, "cod": 15, "ammoniacal_nitrogen": 0.2, "tss": 20}
        quality = impact.data_quality([reading(**lab), reading()])
        self.assertEqual((quality["wqi_ready"], quality["completeness"]["bod"]), (1, 50))


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.folder = Path(tempfile.mkdtemp())
        self.path = self.folder / "test.db"
        database.init_db(self.path)
        with database.open_db(self.path) as conn:
            seed_data.load(conn, seed_data.build_rows())

    def tearDown(self):
        shutil.rmtree(self.folder)

    def test_T21_crud_every_table(self):
        with database.open_db(self.path) as conn:
            person = operations.create_record(
                conn, "participants", {"participant_code": "P90", "role": "Student", "consent": 1})
        answers = {f"q{n}": 3 for n in range(1, 11)}
        samples = {
            "stations": ({"code": "T-1", "name": "n", "river_name": "r", "area": "a"},
                         {"name": "new"}),
            "observers": ({"name": "Temp", "role": "Volunteer"}, {"role": "Lead"}),
            "readings": (reading(at="2026-05-01 09:00"), {"ph": 6.5}),
            "incidents": ({"station_id": 1, "observer_id": 1, "observed_at": "2026-05-01 10:00",
                           "incident_type": "Other", "severity": 1, "status": "Open",
                           "description": "x", "resolved_at": None, "data_source": "synthetic"},
                          {"severity": 3}),
            "participants": ({"participant_code": "P91", "role": "Staff", "consent": 1},
                             {"role": "Student"}),
            "sus_responses": ({"participant_id": person, "submitted_at": "2026-11-01 10:00",
                               **answers, "comment": ""}, {"q1": 5}),
            "task_trials": ({"participant_id": person, "task_name": "T1 Record a new water reading",
                             "method": "manual", "seconds": 60, "success": 1,
                             "recorded_at": "2026-11-01 10:05"}, {"seconds": 55}),
        }
        for table, (new, change) in samples.items():
            with self.subTest(table=table), database.open_db(self.path) as conn:
                key = operations.create_record(conn, table, new)
                self.assertIsNotNone(operations.get_record(conn, table, key))
                self.assertTrue(operations.update_record(conn, table, key, change))
                field, value = next(iter(change.items()))
                self.assertEqual(operations.get_record(conn, table, key)[field], value)
                self.assertTrue(operations.delete_record(conn, table, key))
                self.assertIsNone(operations.get_record(conn, table, key))
                self.assertFalse(operations.delete_record(conn, table, key))

    def assert_blocked(self, action):
        with self.assertRaises(sqlite3.IntegrityError):
            with database.open_db(self.path) as conn:
                action(conn)

    def test_T22_foreign_keys(self):
        self.assert_blocked(lambda c: operations.create_record(
            c, "readings", reading(at="2026-05-01 09:00", station=999)))
        self.assert_blocked(lambda c: operations.delete_record(c, "stations", 1))
        self.assert_blocked(lambda c: operations.delete_record(c, "observers", 1))

    def test_T23_database_rules(self):
        self.assert_blocked(lambda c: operations.create_record(
            c, "readings", reading(at="2026-06-01 09:00")))                       # duplicate
        self.assert_blocked(lambda c: operations.create_record(
            c, "readings", reading(None, None, None, "2026-05-02 09:00")))         # no values
        self.assert_blocked(lambda c: operations.update_record(c, "readings", 1, {"ph": 20}))
        self.assert_blocked(lambda c: operations.update_record(
            c, "incidents", 1, {"status": "Closed"}))                              # no resolved time
        self.assert_blocked(lambda c: operations.update_record(
            c, "incidents", 1, {"status": "Closed", "resolved_at": "2026-01-01 00:00"}))
        self.assert_blocked(lambda c: operations.create_record(
            c, "participants", {"participant_code": "P50", "role": "x", "consent": 0}))

    def test_T24_rollback_and_persistence(self):
        try:
            with database.open_db(self.path) as conn:
                operations.create_record(conn, "observers", {"name": "Lost", "role": "x"})
                raise RuntimeError("forced failure")
        except RuntimeError:
            pass
        with database.open_db(self.path) as conn:
            operations.create_record(conn, "observers", {"name": "Kept", "role": "x"})
        with database.open_db(self.path) as conn:
            names = [r["name"] for r in operations.list_records(conn, "observers")]
        self.assertIn("Kept", names)
        self.assertNotIn("Lost", names)

    def test_T25_injection_text_and_bad_columns(self):
        with database.open_db(self.path) as conn:
            text = "x'); DROP TABLE readings; --"
            operations.update_record(conn, "incidents", 1, {"description": text})
            self.assertEqual(len(operations.list_records(conn, "readings")), 96)
            with self.assertRaises(ValueError):
                operations.update_record(conn, "incidents", 1, {"bad=1; --": 1})

    def test_T26_filters(self):
        with database.open_db(self.path) as conn:
            self.assertEqual(len(operations.search_readings(conn, 1, "2026-06-01", "2026-06-08")), 2)
            self.assertEqual(operations.search_readings(conn, source="field"), [])
            found = operations.search_incidents(conn, status="Open", keyword="SYNTHETIC")
            self.assertTrue(found and all(r["status"] == "Open" for r in found))

    def test_T27_activity_log(self):
        with database.open_db(self.path) as conn:
            self.assertEqual(operations.list_activity(conn), [])        # seeding is not logged
            key = operations.create_record(conn, "observers", {"name": "Logged", "role": "x"})
            operations.update_record(conn, "observers", key, {"role": "y"})
            operations.delete_record(conn, "observers", key)
            actions = [row["action"] for row in operations.list_activity(conn)]
        self.assertEqual(actions, ["create", "update", "delete"])

    def test_T28_csv_import(self):
        path = self.folder / "import.csv"
        seed_data.write_csv(path, seed_data.sample_import_rows())
        with database.open_db(self.path) as conn:
            result = importer.import_readings(conn, path)
            reasons = " ".join(r["reason"] for r in result["rejected"])
            self.assertEqual((result["accepted"], len(result["rejected"])), (3, 4))
            for phrase in ("pH must be", "Unknown station", "real date", "Duplicate"):
                self.assertIn(phrase, reasons)
            self.assertEqual(operations.list_activity(conn)[-1]["action"], "import")
        bad = self.folder / "bad.csv"
        bad.write_text("x,y\n1,2\n", encoding="utf-8")
        with database.open_db(self.path) as conn, self.assertRaises(ValueError):
            importer.import_readings(conn, bad)

    def test_T29_reports(self):
        with database.open_db(self.path) as conn:
            readings = operations.search_readings(conn)
            text = reports.summary_text(operations.list_records(conn, "stations"), readings,
                                        operations.search_incidents(conn))
        for phrase in ("SYNTHETIC", "lowest mean DOE-WQI", "Mann-Kendall", "SYN-C: mean WQI"):
            self.assertIn(phrase, text)
        path = reports.export_csv(readings, "r", self.folder)
        with path.open(encoding="utf-8-sig", newline="") as handle:
            self.assertEqual(len(list(csv.DictReader(handle))), 96)
        path = reports.export_csv([{"note": "=1+1"}], "f", self.folder)
        self.assertIn("'=1+1", path.read_text(encoding="utf-8-sig"))
        with self.assertRaises(ValueError):
            reports.export_csv([], "e", self.folder)

    def test_T30_dashboard(self):
        with database.open_db(self.path) as conn:
            stations = operations.list_records(conn, "stations")
            stations[0]["code"] = "<b>X</b>"
            page = dashboard.build_dashboard(stations, operations.search_readings(conn),
                                             operations.search_incidents(conn), "test")
        self.assertIn("<svg", page)
        self.assertIn("&lt;b&gt;X&lt;/b&gt;", page)
        self.assertNotIn("<b>X</b>", page)
        self.assertTrue(dashboard.save_dashboard(page, self.folder).exists())
        self.assertIn("No WQI values", dashboard.wqi_chart({}))

    def test_T31_seed_not_repeated(self):
        with database.open_db(self.path) as conn:
            self.assertFalse(seed_data.load(conn, seed_data.build_rows()))
            self.assertEqual(len(operations.list_records(conn, "readings")), 96)


class MenuTests(unittest.TestCase):
    """Drive the real program with typed input, on a temporary copy."""

    def setUp(self):
        self.folder = Path(tempfile.mkdtemp()) / "app"
        shutil.copytree(PROJECT, self.folder, ignore=shutil.ignore_patterns(
            "*.db", "reports", "__pycache__"))
        self.run_program("seed_data.py", [])

    def tearDown(self):
        shutil.rmtree(self.folder.parent)

    def run_program(self, script, lines):
        result = subprocess.run(
            [sys.executable, script], cwd=self.folder, text=True,
            input="".join(line + "\n" for line in lines), capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn("Traceback", result.stdout + result.stderr)
        return result.stdout

    def database_value(self, sql):
        with database.open_db(self.folder / "data" / "hydrosight.db") as conn:
            return conn.execute(sql).fetchone()[0]

    def test_T32_add_then_restart(self):
        first = self.run_program("main.py", ["2", "1", "Menu Tester", "Volunteer", "6", "10"])
        self.assertIn("Saved with ID 5", first)
        self.assertIn("Menu Tester", self.run_program("main.py", ["2", "2", "6", "10"]))

    def test_T33_add_reading_shows_wqi(self):
        out = self.run_program("main.py", [
            "3", "1", "1", "1", "2026-11-20 10:00", "20", "7.1", "4.2", "60", "28",
            "3", "20", "0.5", "30", "1", "demo", "6", "10"])
        self.assertIn("pH must be from 0 to 14", out)
        self.assertIn("Saved with ID 97", out)
        self.assertIn("Field flag: CRITICAL. WQI", out)

    def test_T34_bad_input_recovers(self):
        out = self.run_program("main.py", [
            "hello", "99", "3", "1", "abc", "1", "1", "2026-13-01 10:00",
            "2026-05-01 10:00", "20", "q", "6", "10"])
        self.assertIn("Invalid", out)
        self.assertIn("Cancelled", out)

    def test_T35_safe_delete(self):
        out = self.run_program("main.py", [
            "1", "5", "1", "DELETE", "5", "999", "6", "3", "5", "1", "no", "6", "10"])
        self.assertIn("Blocked", out)
        self.assertIn("No record has that ID", out)
        self.assertIn("Nothing was deleted", out)

    def test_T36_close_incident(self):
        out = self.run_program("main.py", [
            "4", "4", "1", "6", "3", "2026-06-01 10:00", "2026-06-05 10:00", "6", "10"])
        self.assertIn("cannot be before the observed time", out)
        self.assertIn("Updated.", out)
        self.assertEqual(self.database_value(
            "SELECT resolved_at FROM incidents WHERE incident_id = 1"), "2026-06-05 10:00")

    def test_T37_search_analytics_exports(self):
        blank = ["", "", "", ""]
        out = self.run_program("main.py", [
            "5", "2", *blank,
            "6", "1", *blank,
            "6", "2", "1", "4",
            "6", "3", "4", "1", "2026-06-01", "2026-08-31", "2026-09-01", "2026-11-30",
            "6", "4", *blank,
            "6", "5", "6.5", "28", "", "2", "15", "0.2", "20", "7",
            "7", "1", *blank, "7", "2", *blank, "7", "3", *blank, "7", "4", *blank,
            "7", "5", *blank, "n", "10"])
        self.assertIn("A value is required", out)
        self.assertIn("WQI = ", out)
        self.assertIn("Mann-Kendall trend test", out)
        self.assertIn("Change (period 2 minus period 1)", out)
        self.assertEqual(out.count("Exported to"), 5)
        names = sorted(p.suffix for p in (self.folder / "reports").iterdir())
        self.assertEqual(names, [".csv", ".csv", ".csv", ".html", ".txt"])

    def test_T38_import_through_menu(self):
        out = self.run_program("main.py", [
            "8", "1", "8", "2", "data/seed/sample_import_SYNTHETIC.csv", "10"])
        self.assertIn("Template created", out)
        self.assertIn("Imported 3 reading(s). Skipped 4.", out)
        self.assertEqual(self.database_value("SELECT COUNT(*) FROM readings"), 99)

    def test_T39_evaluation_flow(self):
        out = self.run_program("main.py", [
            "9", "1", "1", "P02", "Student", "n", "q",
            "1", "P01", "Student", "y", "6",
            "9", "2", "1", "1", "2026-11-25 10:00",
            "4", "2", "5", "1", "3", "3", "4", "1", "3", "1", "", "6",
            "9", "3", "1", "1", "1", "1", "120", "y", "2026-11-25 10:05",
            "1", "1", "1", "2", "30", "y", "2026-11-25 10:10", "6",
            "9", "4", "", "",
            "9", "5", "", "", "10"])
        self.assertIn("only be added after giving consent", out)
        self.assertIn("SUS score for this response: 77.5", out)
        self.assertIn("Respondents: 1; mean 77.5", out)
        self.assertIn("time saved 75.0%", out)
        self.assertIn("Exported to", out)

    def test_T40_edge_cases_and_end_of_input(self):
        out = self.run_program("main.py", [
            "5", "1", "", "2026-07-01", "2026-06-01",
            "7", "3", "999", "", "", "", "10"])
        self.assertIn("start date is after", out)
        self.assertIn("no rows to export", out)
        self.assertIn("Program closed", self.run_program("main.py", []))

    def test_T41_damaged_database(self):
        (self.folder / "data" / "hydrosight.db").write_text("not a database " * 50)
        self.assertIn("could not use its database", self.run_program("main.py", ["10"]))


if __name__ == "__main__":
    unittest.main()

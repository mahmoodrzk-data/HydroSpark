"""Malaysia's DOE Water Quality Index (DOE-WQI). Pure calculations only.

Sub-index equations and weights follow the published DOE formula, as printed
in Malaysian journal papers (see the documentation report for sources).
"""
import math

import config


def saturation_do(temperature: float) -> float:
    """Oxygen solubility in fresh water at 1 atm, in mg/L (APHA 1985 equation)."""
    kelvin = temperature + 273.15
    return math.exp(-139.34410 + 1.575701e5 / kelvin - 6.642308e7 / kelvin ** 2
                    + 1.243800e10 / kelvin ** 3 - 8.621949e11 / kelvin ** 4)


def do_percent(dissolved_oxygen: float, temperature: float) -> float:
    """Convert dissolved oxygen from mg/L to percent saturation."""
    return 100 * dissolved_oxygen / saturation_do(temperature)


def limit_0_100(value: float) -> float:
    """Keep a sub-index between 0 and 100 (project choice; the index is on a 0-100 scale)."""
    return max(0.0, min(100.0, value))


def si_do(x: float) -> float:
    """Sub-index for dissolved oxygen, x in percent saturation."""
    if x <= 8:
        return 0.0
    if x >= 92:
        return 100.0
    return limit_0_100(-0.395 + 0.030 * x ** 2 - 0.00020 * x ** 3)


def si_bod(x: float) -> float:
    """Sub-index for biochemical oxygen demand, x in mg/L."""
    if x <= 5:
        return limit_0_100(100.4 - 4.23 * x)
    return limit_0_100(108 * math.exp(-0.055 * x) - 0.1 * x)


def si_cod(x: float) -> float:
    """Sub-index for chemical oxygen demand, x in mg/L."""
    if x <= 20:
        return limit_0_100(-1.33 * x + 99.1)
    return limit_0_100(103 * math.exp(-0.0157 * x) - 0.04 * x)


def si_an(x: float) -> float:
    """Sub-index for ammoniacal nitrogen, x in mg/L."""
    if x <= 0.3:
        return limit_0_100(100.5 - 105 * x)
    if x < 4:
        return limit_0_100(94 * math.exp(-0.573 * x) - 5 * abs(x - 2))
    return 0.0


def si_ss(x: float) -> float:
    """Sub-index for suspended solids, x in mg/L."""
    if x <= 100:
        return limit_0_100(97.5 * math.exp(-0.00676 * x) + 0.05 * x)
    if x < 1000:
        return limit_0_100(71 * math.exp(-0.0061 * x) - 0.015 * x)
    return 0.0


def si_ph(x: float) -> float:
    """Sub-index for pH."""
    if x < 5.5:
        return limit_0_100(17.2 - 17.2 * x + 5.02 * x ** 2)
    if x < 7:
        return limit_0_100(-242 + 95.5 * x - 6.67 * x ** 2)
    if x < 8.75:
        return limit_0_100(-181 + 82.4 * x - 6.05 * x ** 2)
    return limit_0_100(536 - 77.0 * x + 2.76 * x ** 2)


def sub_indices(reading: dict) -> dict | None:
    """Return the six sub-indices, or None if any required value is missing."""
    needed = ("dissolved_oxygen", "temperature", "bod", "cod",
              "ammoniacal_nitrogen", "tss", "ph")
    if any(reading.get(name) is None for name in needed):
        return None
    return {
        "do": si_do(do_percent(reading["dissolved_oxygen"], reading["temperature"])),
        "bod": si_bod(reading["bod"]),
        "cod": si_cod(reading["cod"]),
        "an": si_an(reading["ammoniacal_nitrogen"]),
        "ss": si_ss(reading["tss"]),
        "ph": si_ph(reading["ph"]),
    }


def calculate_wqi(reading: dict) -> float | None:
    """Weighted sum of the six sub-indices, or None when data are incomplete."""
    parts = sub_indices(reading)
    if parts is None:
        return None
    return sum(config.WQI_WEIGHTS[name] * value for name, value in parts.items())


def wqi_class(value: float) -> str:
    """DOE class: I above 92.7, II 76.5-92.7, III 51.9-76.5, IV 31.0-51.9, V below 31.0."""
    if value > 92.7:
        return "I"
    if value >= 76.5:
        return "II"
    if value >= 51.9:
        return "III"
    if value >= 31.0:
        return "IV"
    return "V"


def wqi_status(value: float) -> str:
    """DOE status: clean 81-100, slightly polluted 60-80, polluted 0-59."""
    if value >= 81:
        return "Clean"
    if value >= 60:
        return "Slightly polluted"
    return "Polluted"

"""HydroSight: river quality and pollution analytics. Program entry point and menus."""
import sqlite3
import webbrowser
from collections import Counter
from collections.abc import Callable
from datetime import datetime
from functools import partial

import analytics
import config
import dashboard
import database
import impact
import importer
import operations
import reports
import ui
import validation
import wqi

OPTIONS: dict[str, tuple[str, ...]] = {
    "incident_type": config.INCIDENT_TYPES,
    "status": config.STATUSES,
    "data_source": config.DATA_SOURCES,
    "task_name": config.EVALUATION_TASKS,
    "method": config.TASK_METHODS,
}
BLANKABLE: tuple[str, ...] = (*config.MEASURES, "notes", "comment")
WQI_INPUTS: tuple[str, ...] = ("dissolved_oxygen", "temperature", "bod", "cod",
                               "ammoniacal_nitrogen", "tss", "ph")


def build_fields() -> dict[str, tuple[str, Callable[[str], object]]]:
    """Map every form field to its question and its validation function."""
    fields: dict[str, tuple[str, Callable[[str], object]]] = {
        "code": ("Station code, e.g. UM-01", validation.station_code),
        "name": ("Name", validation.required_text),
        "river_name": ("River name", validation.required_text),
        "area": ("Area", validation.required_text),
        "role": ("Role", validation.required_text),
        "station_id": ("Station ID", validation.positive_int),
        "observer_id": ("Observer ID", validation.positive_int),
        "participant_id": ("Participant ID", validation.positive_int),
        "participant_code": ("Participant code, e.g. P01", validation.participant_code),
        "consent": ("Has this person agreed to take part, with answers used anonymously? (y/n)",
                    validation.consent),
        "sampled_at": ("Sampled at, YYYY-MM-DD HH:MM", validation.timestamp),
        "observed_at": ("Observed at, YYYY-MM-DD HH:MM", validation.timestamp),
        "submitted_at": ("Submitted at, YYYY-MM-DD HH:MM", validation.timestamp),
        "recorded_at": ("Recorded at, YYYY-MM-DD HH:MM", validation.timestamp),
        "severity": ("Severity 1-3", validation.severity),
        "description": ("Description (what was seen)", validation.required_text),
        "notes": ("Notes", validation.optional_text),
        "comment": ("Comment", validation.optional_text),
        "seconds": ("Time taken in seconds", validation.seconds),
        "success": ("Was the task completed correctly? (y/n)", validation.success),
    }
    for name, (label, _, _) in config.MEASURES.items():
        fields[name] = (label, partial(validation.measurement, parameter=name))
    for number, statement in enumerate(config.SUS_STATEMENTS, start=1):
        fields[f"q{number}"] = (f"Q{number}. {statement}\n    1 = strongly disagree, "
                                f"5 = strongly agree", validation.likert)
    return fields


FIELDS = build_fields()


def form_fields(table: str) -> list[str]:
    """Fields the user types for a table (resolved_at is asked only when needed)."""
    return [field for field in operations.TABLES[table][1] if field != "resolved_at"]


def ask_field(field: str) -> object:
    """Ask for one field using the right input style."""
    if field in OPTIONS:
        return ui.ask_choice(field.replace("_", " ").capitalize(), OPTIONS[field])
    prompt, check = FIELDS[field]
    if field in BLANKABLE:
        prompt += " (blank = none)"
    return ui.ask(prompt, check)


def ask_resolved(status: str, observed_at: str) -> str | None:
    """Ask when an incident was resolved, but only if it is Closed."""
    if status != "Closed":
        return None
    return ui.ask("Resolved at, YYYY-MM-DD HH:MM",
                  partial(validation.resolved_time, observed_at=observed_at))


def show_reference_lists(conn: sqlite3.Connection, table: str) -> None:
    """Show the IDs a form will need before the user types them."""
    if table in ("readings", "incidents"):
        print("\nStations")
        ui.show_table(operations.list_records(conn, "stations"))
        print("\nObservers")
        ui.show_table(operations.list_records(conn, "observers"))
    elif table in ("sus_responses", "task_trials"):
        print("\nParticipants")
        ui.show_table(operations.list_records(conn, "participants"))


def describe_reading(reading: dict) -> str:
    """Explain the result of one reading in a sentence."""
    text = f"Field flag: {analytics.flag_reading(reading)}."
    value = wqi.calculate_wqi(reading)
    if value is None:
        return text + " WQI not calculated (needs DO, temperature, pH, BOD, COD, AN and TSS)."
    return text + f" WQI {value:.1f}: Class {wqi.wqi_class(value)}, {wqi.wqi_status(value)}."


def create_form(conn: sqlite3.Connection, table: str) -> None:
    """Collect every field, then insert the record."""
    show_reference_lists(conn, table)
    data = {field: ask_field(field) for field in form_fields(table)}
    if table == "incidents":
        data["resolved_at"] = ask_resolved(data["status"], data["observed_at"])
    new_id = operations.create_record(conn, table, data)
    conn.commit()
    print(f"Saved with ID {new_id}.")
    if table == "readings":
        print(describe_reading(data))
    elif table == "sus_responses":
        print(f"SUS score for this response: {impact.sus_score(data):.1f} out of 100.")


def pick_record(conn: sqlite3.Connection, table: str) -> tuple[int, dict] | None:
    """Ask for an ID and show that record."""
    record_id = ui.ask("Record ID", validation.positive_int)
    record = operations.get_record(conn, table, record_id)
    if record is None:
        print("No record has that ID.")
        return None
    ui.show_table([record])
    return record_id, record


def update_form(conn: sqlite3.Connection, table: str) -> None:
    """Change one field at a time."""
    found = pick_record(conn, table)
    if found is None:
        return
    record_id, record = found
    field = ui.ask_choice("Field to change", form_fields(table))
    show_reference_lists(conn, table if field.endswith("_id") else "")
    value = ask_field(field)
    changes = {field: value}
    if table == "incidents" and field == "status":
        changes["resolved_at"] = ask_resolved(value, record["observed_at"])
    operations.update_record(conn, table, record_id, changes)
    conn.commit()
    print("Updated.")


def delete_form(conn: sqlite3.Connection, table: str) -> None:
    """Delete only after the user types DELETE."""
    found = pick_record(conn, table)
    if found is None:
        return
    if input("Type DELETE to confirm: ") != "DELETE":
        print("Nothing was deleted.")
        return
    operations.delete_record(conn, table, found[0])
    conn.commit()
    print("Deleted.")


def crud_menu(conn: sqlite3.Connection, table: str) -> None:
    """Submenu for one table."""
    actions = ("Add", "View all", "View one", "Update", "Delete", "Back")
    while True:
        try:
            action = ui.ask_choice(f"Manage {table.replace('_', ' ')}", actions)
        except ui.Cancelled:
            return
        if action == "Back":
            return
        run_safely(conn, partial(run_crud_action, conn, table, action))


def run_crud_action(conn: sqlite3.Connection, table: str, action: str) -> None:
    """Carry out the chosen CRUD action."""
    if action == "Add":
        create_form(conn, table)
    elif action == "View all":
        ui.show_table(operations.list_records(conn, table))
    elif action == "View one":
        pick_record(conn, table)
    elif action == "Update":
        update_form(conn, table)
    else:
        delete_form(conn, table)


def run_safely(conn: sqlite3.Connection, task: Callable[[], None]) -> None:
    """Run one task and turn expected errors into clear messages."""
    try:
        task()
    except ui.Cancelled:
        conn.rollback()
        print("Cancelled. Nothing further was saved.")
    except sqlite3.IntegrityError as error:
        conn.rollback()
        text = str(error)
        if "FOREIGN KEY" in text:
            print("Blocked: the ID does not exist, or other records still use this one.")
        elif "UNIQUE" in text:
            print("Blocked: that record already exists (duplicate).")
        else:
            print("Blocked by a database rule (for example a value out of range, "
                  "or a Closed incident without a resolved time).")
    except sqlite3.Error as error:
        conn.rollback()
        print(f"Database problem: {error}")
    except OSError as error:
        conn.rollback()
        print(f"File problem: {error}")
    except ValueError as error:
        conn.rollback()
        print(f"Cannot continue: {error}")


def ask_dates() -> tuple[str | None, str | None]:
    """Ask for an optional date range."""
    start = ui.ask_optional("From date YYYY-MM-DD", validation.date_only)
    end = ui.ask_optional("To date YYYY-MM-DD", validation.date_only)
    validation.date_range(start, end)
    return start, end


def ask_filters(conn: sqlite3.Connection) -> dict:
    """Ask for an optional station, date range and data source."""
    ui.show_table(operations.list_records(conn, "stations"))
    station_id = ui.ask_optional("Station ID", validation.positive_int)
    start, end = ask_dates()
    ui.show_options("Data source", config.DATA_SOURCES)
    source = ui.ask_optional("Number", partial(validation.choice, options=config.DATA_SOURCES))
    return {"station_id": station_id, "start": start, "end": end, "source": source}


def ask_parameter() -> str:
    """Choose a parameter by its readable label."""
    labels = [config.LABELS[name] for name in config.ANALYSIS_PARAMETERS]
    chosen = ui.ask_choice("Parameter", labels)
    return config.ANALYSIS_PARAMETERS[labels.index(chosen)]


def period_label(filters: dict) -> str:
    """Describe the filters for a report heading."""
    return (f"{filters['start'] or 'first record'} to {filters['end'] or 'last record'}; "
            f"source: {filters['source'] or 'all'}")


def selected_stations(conn: sqlite3.Connection, filters: dict) -> list[dict]:
    """All stations, or only the one chosen in the filters."""
    stations = operations.list_records(conn, "stations")
    if filters["station_id"] is not None:
        stations = [s for s in stations if s["station_id"] == filters["station_id"]]
    return stations


def reading_rows(readings: list[dict]) -> list[dict]:
    """Compact reading rows for the screen, with WQI and field flag."""
    keys = ("reading_id", "station_code", "sampled_at", "ph", "dissolved_oxygen",
            "turbidity", "temperature")
    return [{**{k: r[k] for k in keys},
             "wqi": None if r["wqi"] is None else round(r["wqi"], 1),
             "class": r["wqi_class"], "flag": r["flag"], "source": r["data_source"]}
            for r in analytics.add_wqi(readings)]


def export_rows(readings: list[dict]) -> list[dict]:
    """Full reading rows for a CSV file, with WQI rounded."""
    return [{**r, "wqi": None if r["wqi"] is None else round(r["wqi"], 2)}
            for r in analytics.add_wqi(readings)]


def search_menu(conn: sqlite3.Connection) -> None:
    """Search readings, incidents or the activity log."""
    kind = ui.ask_choice("Search", ("Readings", "Flagged readings only", "Incidents",
                                    "Activity log"))
    if kind == "Activity log":
        start, end = ask_dates()
        ui.show_table(operations.list_activity(conn, start, end))
        return
    filters = ask_filters(conn)
    if kind == "Incidents":
        for field in ("incident_type", "status"):
            ui.show_options(field.replace("_", " ").capitalize(), OPTIONS[field])
            filters[field] = ui.ask_optional(
                "Number", partial(validation.choice, options=OPTIONS[field]))
        filters["keyword"] = ui.ask_optional("Word in description", str.strip)
        ui.show_table(operations.search_incidents(conn, **filters))
        return
    rows = reading_rows(operations.search_readings(conn, **filters))
    if kind == "Flagged readings only":
        rows = [r for r in rows if r["flag"] in ("WATCH", "CRITICAL")]
    ui.show_table(rows)


def show_station_analysis(conn: sqlite3.Connection) -> None:
    """Statistics, monthly trend, trend test and unusual values for one station."""
    ui.show_table(operations.list_records(conn, "stations"))
    station_id = ui.ask("Station ID", validation.positive_int)
    parameter = ask_parameter()
    rows = analytics.add_wqi(operations.search_readings(conn, station_id=station_id))
    if not rows:
        print("No readings for that station.")
        return
    stats = analytics.describe(rows, parameter)
    print(f"\n{config.LABELS[parameter]}: n={stats['n']}, missing={stats['missing']}")
    print("  " + ", ".join(f"{k}={reports.number(stats[k], 2)}"
                          for k in ("mean", "median", "sd", "min", "max")))
    months = analytics.monthly_means(rows, parameter)
    smooth = analytics.moving_average([mean for _, _, mean in months])
    ui.show_table([{"month": m, "n": n, "mean": round(avg, 2),
                    "3_month_average": reports.number(ma, 2)}
                   for (m, n, avg), ma in zip(months, smooth)])
    trend = analytics.trend_summary(rows, parameter)
    p_text = "n/a" if trend["p"] is None else f"{trend['p']:.4f}"
    print(f"Mann-Kendall trend test: {trend['trend']} (S={trend['s']}, n={trend['n']}, "
          f"p={p_text})")
    print(f"Sen's slope: {reports.number(trend['slope_30d'], 2)} per 30 days "
          "(a description, not a forecast)")
    if parameter == "wqi":
        classes = Counter(r["wqi_class"] for r in rows if r["wqi_class"])
        print("WQI classes: " + ", ".join(f"Class {c}: {classes[c]}" for c in sorted(classes)))
    unusual = analytics.find_outliers(rows, parameter)
    print("Unusual values to verify (not automatically errors):")
    ui.show_table([{"reading_id": r["reading_id"], "sampled_at": r["sampled_at"],
                    "value": round(r[parameter], 2), "modified_z": round(z, 2)}
                   for r, z in unusual])


def show_comparison(conn: sqlite3.Connection) -> None:
    """Compare one station's mean between two non-overlapping periods."""
    ui.show_table(operations.list_records(conn, "stations"))
    station_id = ui.ask("Station ID", validation.positive_int)
    parameter = ask_parameter()
    dates = [ui.ask(f"{label} YYYY-MM-DD", validation.date_only)
             for label in ("Period 1 start", "Period 1 end", "Period 2 start", "Period 2 end")]
    validation.date_range(dates[0], dates[1])
    validation.date_range(dates[2], dates[3])
    if dates[1] >= dates[2]:
        raise ValueError("Period 2 must start after Period 1 ends.")
    first = analytics.add_wqi(operations.search_readings(conn, station_id, dates[0], dates[1]))
    second = analytics.add_wqi(operations.search_readings(conn, station_id, dates[2], dates[3]))
    result = analytics.compare_periods(first, second, parameter)
    for label, key in (("Period 1", "first"), ("Period 2", "second")):
        print(f"{label}: n={result[key]['n']}, mean={reports.number(result[key]['mean'], 2)}")
    print(f"Change (period 2 minus period 1): {reports.number(result['change'], 2)}")
    print("A difference does not show what caused it.")


def show_response_performance(conn: sqlite3.Connection) -> None:
    """How quickly incidents are being closed."""
    filters = ask_filters(conn)
    incidents = operations.search_incidents(conn, **filters)
    result = analytics.response_times(incidents, datetime.now().strftime(config.TIME_FORMAT))
    print(f"\nIncidents: {result['total']}; closed: {result['closed']} "
          f"({reports.percent(result['closure_rate'])})")
    print(f"Days to close: median {reports.number(result['median_days'])}, "
          f"mean {reports.number(result['mean_days'])}")
    print(f"Unresolved: {result['unresolved']}; unresolved for over "
          f"{config.BACKLOG_DAYS} days: {result['overdue']}")


def wqi_calculator() -> None:
    """Calculate the DOE-WQI for one sample without saving it."""
    print("Enter one sample's values. All seven are needed.")
    sample = {name: ui.ask(config.MEASURES[name][0],
                           partial(validation.required_measurement, parameter=name))
              for name in WQI_INPUTS}
    print(f"Dissolved oxygen saturation: "
          f"{wqi.do_percent(sample['dissolved_oxygen'], sample['temperature']):.1f}%")
    parts = wqi.sub_indices(sample)
    ui.show_table([{"sub_index": name.upper(), "value": round(value, 2),
                    "weight": config.WQI_WEIGHTS[name],
                    "weighted": round(value * config.WQI_WEIGHTS[name], 2)}
                   for name, value in parts.items()])
    value = wqi.calculate_wqi(sample)
    print(f"WQI = {value:.1f}: Class {wqi.wqi_class(value)}, {wqi.wqi_status(value)}")


def build_summary(conn: sqlite3.Connection, filters: dict) -> str:
    """Gather filtered data and create the summary text."""
    return reports.summary_text(
        selected_stations(conn, filters), operations.search_readings(conn, **filters),
        operations.search_incidents(conn, **filters), period_label(filters))


def analytics_menu(conn: sqlite3.Connection) -> None:
    """Choose an analysis, then record that it was used."""
    action = ui.ask_choice("Analytics", (
        "Overview and station ranking", "One station in detail", "Compare two periods",
        "Incident response performance", "WQI calculator"))
    if action == "One station in detail":
        show_station_analysis(conn)
    elif action == "Compare two periods":
        show_comparison(conn)
    elif action == "Incident response performance":
        show_response_performance(conn)
    elif action == "WQI calculator":
        wqi_calculator()
    else:
        print("\n" + build_summary(conn, ask_filters(conn)))
    operations.log_activity(conn, "analysis", "", None, action)
    conn.commit()


def export_menu(conn: sqlite3.Connection) -> None:
    """Export a filtered report or the HTML dashboard."""
    kind = ui.ask_choice("Reports and dashboard", (
        "Text summary", "Station ranking CSV", "Readings CSV", "Incidents CSV",
        "HTML dashboard"))
    filters = ask_filters(conn)
    stations = selected_stations(conn, filters)
    readings = operations.search_readings(conn, **filters)
    incidents = operations.search_incidents(conn, **filters)
    if kind == "Text summary":
        path = reports.export_text(reports.summary_text(
            stations, readings, incidents, period_label(filters)))
    elif kind == "Readings CSV":
        path = reports.export_csv(export_rows(readings), "readings")
    elif kind == "Incidents CSV":
        path = reports.export_csv(incidents, "incidents")
    elif kind == "Station ranking CSV":
        ranking = analytics.rank_stations(stations, readings, incidents)
        extra = {"period": period_label(filters), "note": "DOE-WQI; screening only"}
        path = reports.export_csv([{**row, **extra} for row in ranking], "ranking")
    else:
        path = dashboard.save_dashboard(dashboard.build_dashboard(
            stations, readings, incidents, period_label(filters)))
    operations.log_activity(conn, "export", "", None, f"{kind}: {path.name}")
    conn.commit()
    print(f"Exported to {path}")
    if kind == "HTML dashboard" and ui.ask_yes_no("Open it in your web browser now?"):
        webbrowser.open(path.as_uri())


def import_menu(conn: sqlite3.Connection) -> None:
    """Create a CSV template or import readings from a CSV file."""
    action = ui.ask_choice("Import data", ("Create a blank CSV template",
                                           "Import readings from a CSV file"))
    if action == "Create a blank CSV template":
        print(f"Template created: {importer.write_template()}")
        print("Fill one row per reading. Stations and observers must already exist.")
        return
    path = ui.ask("Path of the CSV file", validation.csv_path)
    result = importer.import_readings(conn, path)
    conn.commit()
    print(f"Imported {result['accepted']} reading(s). Skipped {len(result['rejected'])}.")
    if result["rejected"]:
        ui.show_table(result["rejected"])
        print(f"Reasons saved to {reports.export_csv(result['rejected'], 'import_rejections')}")


def build_impact(conn: sqlite3.Connection, start: str | None, end: str | None) -> str:
    """Gather evaluation data and create the impact report text."""
    trials = operations.list_trials(conn)
    now = datetime.now().strftime(config.TIME_FORMAT)
    return reports.impact_text(
        impact.usage_summary(operations.list_activity(conn, start, end)),
        impact.sus_summary(operations.list_sus(conn)),
        impact.task_comparison(trials), impact.paired_savings(trials),
        impact.data_quality(operations.search_readings(conn, start=start, end=end)),
        analytics.response_times(operations.search_incidents(conn, start=start, end=end), now),
        f"{start or 'first record'} to {end or 'last record'}")


def evaluation_menu(conn: sqlite3.Connection) -> None:
    """Record user testing and measure the system's use and impact."""
    action = ui.ask_choice("Evaluation and impact", (
        "Participants", "SUS questionnaire responses", "Task timing trials",
        "Usage and impact summary", "Export impact report"))
    tables = {"Participants": "participants", "SUS questionnaire responses": "sus_responses",
              "Task timing trials": "task_trials"}
    if action in tables:
        crud_menu(conn, tables[action])
        return
    start, end = ask_dates()
    text = build_impact(conn, start, end)
    if action == "Usage and impact summary":
        print("\n" + text)
        operations.log_activity(conn, "analysis", "", None, action)
    else:
        path = reports.export_text(text, "impact")
        operations.log_activity(conn, "export", "", None, f"Impact report: {path.name}")
        print(f"Exported to {path}")
    conn.commit()


def main() -> None:
    """Start the program and run the main menu."""
    menu = ("Stations", "Observers", "Water readings", "Pollution incidents",
            "Search and filter", "Analytics", "Reports and dashboard", "Import data",
            "Evaluation and impact", "Exit")
    tables = {"Stations": "stations", "Observers": "observers",
              "Water readings": "readings", "Pollution incidents": "incidents"}
    screens = {"Search and filter": search_menu, "Analytics": analytics_menu,
               "Reports and dashboard": export_menu, "Import data": import_menu,
               "Evaluation and impact": evaluation_menu}
    try:
        database.init_db()
        with database.open_db() as conn:
            while True:
                try:
                    selected = ui.ask_choice(
                        f"{config.APP_NAME}: RIVER QUALITY AND POLLUTION ANALYTICS", menu)
                except ui.Cancelled:
                    selected = "Exit"
                if selected == "Exit":
                    print("Goodbye.")
                    return
                if selected in tables:
                    crud_menu(conn, tables[selected])
                else:
                    run_safely(conn, partial(screens[selected], conn))
    except (KeyboardInterrupt, EOFError):
        print("\nProgram closed.")
    except (sqlite3.Error, OSError) as error:
        print(f"The program could not use its database or files: {error}")


if __name__ == "__main__":
    main()

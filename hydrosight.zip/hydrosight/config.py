"""Fixed settings shared by every module of HydroSight."""
from pathlib import Path

APP_NAME: str = "HydroSight"
BASE_DIR: Path = Path(__file__).resolve().parent
DB_PATH: Path = BASE_DIR / "data" / "hydrosight.db"
SCHEMA_PATH: Path = BASE_DIR / "schema.sql"
REPORT_DIR: Path = BASE_DIR / "reports"
TIME_FORMAT: str = "%Y-%m-%d %H:%M"

# name -> (label, lowest accepted, highest accepted).
# Data-entry plausibility limits chosen by the project. NOT water standards.
MEASURES: dict[str, tuple[str, float, float]] = {
    "ph": ("pH", 0.0, 14.0),
    "dissolved_oxygen": ("Dissolved oxygen (mg/L)", 0.0, 20.0),
    "turbidity": ("Turbidity (NTU)", 0.0, 4000.0),
    "temperature": ("Water temperature (deg C)", 0.0, 45.0),
    "bod": ("BOD (mg/L)", 0.0, 1000.0),
    "cod": ("COD (mg/L)", 0.0, 5000.0),
    "ammoniacal_nitrogen": ("Ammoniacal nitrogen (mg/L)", 0.0, 500.0),
    "tss": ("Total suspended solids (mg/L)", 0.0, 10000.0),
}
FIELD_MEASURES: tuple[str, ...] = ("ph", "dissolved_oxygen", "turbidity", "temperature")
LAB_MEASURES: tuple[str, ...] = ("bod", "cod", "ammoniacal_nitrogen", "tss")
LABELS: dict[str, str] = {"wqi": "DOE Water Quality Index (0-100)",
                          **{name: info[0] for name, info in MEASURES.items()}}
ANALYSIS_PARAMETERS: tuple[str, ...] = ("wqi", *MEASURES)

# Field screening limits: pH, dissolved oxygen and turbidity rows for Class IIB of
# Malaysia's Interim National Water Quality Standards, as reproduced by WEPA.
# Treating DO below 5 mg/L as outside the limit is a PROJECT interpretation.
# (lowest accepted, highest accepted); None means no limit on that side.
SCREENING_LIMITS: dict[str, tuple[float | None, float | None]] = {
    "ph": (6.0, 9.0),
    "dissolved_oxygen": (5.0, None),
    "turbidity": (None, 50.0),
}

# Weights of the six sub-indices in the published DOE-WQI formula.
WQI_WEIGHTS: dict[str, float] = {
    "do": 0.22, "bod": 0.19, "cod": 0.16, "an": 0.15, "ss": 0.16, "ph": 0.12}

INCIDENT_TYPES: tuple[str, ...] = (
    "Solid waste", "Suspected chemical runoff", "Suspected sewage",
    "Silt or sediment", "Other")
STATUSES: tuple[str, ...] = ("Open", "Under review", "Closed")
DATA_SOURCES: tuple[str, ...] = ("synthetic", "field", "public")
ACTIONS: tuple[str, ...] = ("create", "update", "delete", "import", "export", "analysis")

# Usability evaluation.
# System Usability Scale (SUS) statements, Brooke (1996); free to use with acknowledgement.
SUS_STATEMENTS: tuple[str, ...] = (
    "I think that I would like to use this system frequently.",
    "I found the system unnecessarily complex.",
    "I thought the system was easy to use.",
    "I think that I would need the support of a technical person to be able to use this system.",
    "I found the various functions in this system were well integrated.",
    "I thought there was too much inconsistency in this system.",
    "I would imagine that most people would learn to use this system very quickly.",
    "I found the system very cumbersome to use.",
    "I felt very confident using the system.",
    "I needed to learn a lot of things before I could get going with this system.",
)
SUS_BENCHMARK: float = 68.0   # commonly cited average SUS score
EVALUATION_TASKS: tuple[str, ...] = (
    "T1 Record a new water reading",
    "T2 Find the station with the lowest water quality",
    "T3 Produce a summary for a stakeholder",
)
TASK_METHODS: tuple[str, ...] = ("manual", "software")

MIN_READINGS_FOR_SCORE: int = 3   # project choice
MIN_POINTS_FOR_TREND: int = 10    # normal approximation used from 10 values (project choice)
TREND_ALPHA: float = 0.05         # significance level for the trend test
OUTLIER_CUTOFF: float = 3.5       # modified z-score (Iglewicz and Hoaglin)
BACKLOG_DAYS: int = 14            # an unresolved incident older than this is "overdue" (project choice)

"""Download reports: text summary, CSV files and the HTML dashboard."""
import streamlit.components.v1 as components
import streamlit as st

import analytics
import dashboard
import main
import operations
import reports
import web_common as wc

wc.start_page("Reports and dashboard")
filters = wc.sidebar_filters()
period = main.period_label(filters)
with wc.connect() as conn:
    stations = main.selected_stations(conn, filters)
    readings = operations.search_readings(conn, **filters)
    incidents = operations.search_incidents(conn, **filters)

summary = reports.summary_text(stations, readings, incidents, period)
ranking = [{**row, "period": period, "note": "DOE-WQI; screening only"}
           for row in analytics.rank_stations(stations, readings, incidents)]
page = dashboard.build_dashboard(stations, readings, incidents, period)
downloads = [
    ("Text summary", summary.encode("utf-8"), "summary.txt", "text/plain"),
    ("Station ranking CSV", wc.csv_bytes(ranking), "ranking.csv", "text/csv"),
    ("Readings CSV", wc.csv_bytes(main.export_rows(readings)), "readings.csv", "text/csv"),
    ("Incidents CSV", wc.csv_bytes(incidents), "incidents.csv", "text/csv"),
    ("HTML dashboard", page.encode("utf-8"), "dashboard.html", "text/html"),
]
st.write(f"Period: {period}. Every download is recorded in the activity log.")
for column, (label, data, name, mime) in zip(st.columns(len(downloads)), downloads):
    column.download_button(label, data=data, file_name=name, mime=mime, key=f"download_{name}",
                           disabled=not data, on_click=wc.log_use,
                           args=("export", f"{label} (web)"))

summary_tab, dashboard_tab = st.tabs(["Text summary", "Dashboard preview"])
with summary_tab:
    st.text(summary)
with dashboard_tab:
    components.html(page, height=1400, scrolling=True)

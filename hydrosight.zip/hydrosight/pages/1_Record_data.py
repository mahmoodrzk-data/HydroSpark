"""Record new water readings, pollution incidents, stations and observers."""
import streamlit as st

import config
import main
import operations
import validation
import web_common as wc

wc.start_page("Record data")
if not wc.require_editor():
    st.stop()


def save(table: str, data: dict) -> int:
    """Insert one record (the insert is also written to the activity log)."""
    with wc.connect() as conn:
        return operations.create_record(conn, table, data)


reading_tab, incident_tab, station_tab, observer_tab = st.tabs(
    ["Water reading", "Pollution incident", "Station", "Observer"])

with reading_tab:
    if not wc.records("stations") or not wc.records("observers"):
        st.warning("Add at least one station and one observer first.")
    else:
        with st.form("reading_form"):
            station_id = wc.pick_station(key="reading_station")
            observer_id = wc.pick_observer(key="reading_observer")
            when = wc.when_input("Sampled", "reading_when")
            texts = {}
            st.markdown("**Field measurements** (leave blank if not measured)")
            for column, name in zip(st.columns(4), config.FIELD_MEASURES):
                texts[name] = column.text_input(config.MEASURES[name][0], key=f"reading_{name}")
            st.markdown("**Laboratory results** (all four are needed for the WQI)")
            for column, name in zip(st.columns(4), config.LAB_MEASURES):
                texts[name] = column.text_input(config.MEASURES[name][0], key=f"reading_{name}")
            source = st.selectbox("Data source", config.DATA_SOURCES, index=1, key="reading_source")
            notes = st.text_input("Notes (optional)", key="reading_notes")
            submitted = st.form_submit_button("Save reading")
        if submitted:
            def save_reading() -> str:
                """Check every value, save the reading and explain the result."""
                values = {name: validation.measurement(texts[name], name)
                          for name in config.MEASURES}
                if all(value is None for value in values.values()):
                    raise ValueError("Enter at least one measurement.")
                data = {"station_id": station_id, "observer_id": observer_id,
                        "sampled_at": validation.timestamp(when), **values,
                        "data_source": source, "notes": validation.optional_text(notes)}
                new_id = save("readings", data)
                return f"Saved with ID {new_id}. {main.describe_reading(data)}"
            wc.run_action(save_reading)

with incident_tab:
    if not wc.records("stations") or not wc.records("observers"):
        st.warning("Add at least one station and one observer first.")
    else:
        with st.form("incident_form"):
            station_id = wc.pick_station(key="incident_station")
            observer_id = wc.pick_observer(key="incident_observer")
            observed = wc.when_input("Observed", "incident_when")
            kind = st.selectbox("Incident type", config.INCIDENT_TYPES, key="incident_type")
            severity = st.selectbox("Severity", (1, 2, 3), key="incident_severity",
                                    format_func=lambda s: wc.SEVERITY_LABELS[s])
            status = st.selectbox("Status", config.STATUSES, key="incident_status")
            description = st.text_area("Description (what was seen)", key="incident_description")
            st.caption("Resolved date and time: only used when the status is Closed.")
            resolved = wc.when_input("Resolved", "incident_resolved")
            source = st.selectbox("Data source", config.DATA_SOURCES, index=1,
                                  key="incident_source")
            submitted = st.form_submit_button("Save incident")
        if submitted:
            def save_incident() -> str:
                """Check the incident and save it."""
                observed_at = validation.timestamp(observed)
                data = {"station_id": station_id, "observer_id": observer_id,
                        "observed_at": observed_at, "incident_type": kind,
                        "severity": severity, "status": status,
                        "description": validation.required_text(description),
                        "resolved_at": (validation.resolved_time(resolved, observed_at)
                                        if status == "Closed" else None),
                        "data_source": source}
                return f"Saved with ID {save('incidents', data)}."
            wc.run_action(save_incident)

with station_tab:
    with st.form("station_form", clear_on_submit=True):
        code = st.text_input("Station code, for example SW-01", key="station_code")
        name = st.text_input("Name", key="station_name")
        river = st.text_input("River name", key="station_river")
        area = st.text_input("Area", key="station_area")
        submitted = st.form_submit_button("Save station")
    if submitted:
        wc.run_action(lambda: "Saved with ID {}.".format(save("stations", {
            "code": validation.station_code(code), "name": validation.required_text(name),
            "river_name": validation.required_text(river),
            "area": validation.required_text(area)})))
    wc.show_table(wc.records("stations"), "No stations yet.")

with observer_tab:
    with st.form("observer_form", clear_on_submit=True):
        name = st.text_input("Name", key="observer_name")
        role = st.text_input("Role, for example Volunteer", key="observer_role")
        submitted = st.form_submit_button("Save observer")
    if submitted:
        wc.run_action(lambda: "Saved with ID {}.".format(save("observers", {
            "name": validation.required_text(name), "role": validation.required_text(role)})))
    wc.show_table(wc.records("observers"), "No observers yet.")

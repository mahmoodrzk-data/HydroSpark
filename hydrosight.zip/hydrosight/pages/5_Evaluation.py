"""User testing and impact: participants, SUS questionnaire, timed tasks and the impact report."""
import streamlit as st

import config
import impact
import main
import operations
import validation
import web_common as wc

wc.start_page("Evaluation and impact")
st.write("Use this page during real user testing. Only anonymous codes (P01, P02 ...) are "
         "stored. Add a person only after they agree to take part.")

with wc.connect() as conn:
    sus = impact.sus_summary(operations.list_sus(conn))
    pairs = impact.paired_savings(operations.list_trials(conn))
tiles = st.columns(4)
tiles[0].metric("SUS responses", sus["n"])
tiles[1].metric("Mean SUS (0-100)", "n/a" if sus["mean"] is None else f"{sus['mean']:.1f}")
tiles[2].metric("Paired task comparisons", pairs["pairs"])
saving = pairs["median_saving_pct"]
tiles[3].metric("Median time saved", "n/a" if saving is None else f"{saving:.0f}%")

report_tab, participant_tab, sus_tab, trial_tab = st.tabs(
    ["Impact report", "Add participant", "SUS questionnaire", "Timed task"])

with report_tab:
    with wc.connect() as conn:
        text = main.build_impact(conn, None, None)
    st.text(text)
    st.download_button("Download impact report", data=text.encode("utf-8"),
                       file_name="impact_report.txt", mime="text/plain", key="download_impact",
                       on_click=wc.log_use, args=("export", "Impact report (web)"))

with participant_tab:
    if wc.require_editor():
        with st.form("participant_form", clear_on_submit=True):
            code = st.text_input("Participant code, for example P01", key="participant_code")
            role = st.text_input("Role, for example Student or Resident", key="participant_role")
            agreed = st.checkbox("This person agreed to take part, with answers used anonymously",
                                 key="participant_consent")
            submitted = st.form_submit_button("Add participant")
        if submitted:
            def add_participant() -> str:
                """Save a participant only when consent was given."""
                if not agreed:
                    raise ValueError("A participant can only be added after giving consent.")
                with wc.connect() as conn:
                    new_id = operations.create_record(conn, "participants", {
                        "participant_code": validation.participant_code(code),
                        "role": validation.required_text(role), "consent": 1})
                return f"Saved with ID {new_id}."
            wc.run_action(add_participant)

with sus_tab:
    if wc.require_editor() and wc.records("participants"):
        st.write("1 = strongly disagree, 5 = strongly agree. Every statement needs an answer.")
        with st.form("sus_form"):
            person = wc.pick_participant(key="sus_participant")
            answers = {f"q{n}": st.radio(f"Q{n}. {statement}", (1, 2, 3, 4, 5), index=None,
                                         horizontal=True, key=f"sus_q{n}")
                       for n, statement in enumerate(config.SUS_STATEMENTS, start=1)}
            comment = st.text_input("Comment (optional)", key="sus_comment")
            submitted = st.form_submit_button("Save response")
        if submitted:
            def save_sus() -> str:
                """Save one complete questionnaire and show its score."""
                if any(value is None for value in answers.values()):
                    raise ValueError("Answer all 10 statements.")
                data = {"participant_id": person, "submitted_at": wc.now_text(), **answers,
                        "comment": validation.optional_text(comment)}
                with wc.connect() as conn:
                    operations.create_record(conn, "sus_responses", data)
                score = impact.sus_score(data)
                return f"Saved. SUS score for this response: {score:.1f} out of 100."
            wc.run_action(save_sus)
    elif wc.can_edit():
        st.info("Add a participant first.")

with trial_tab:
    if wc.require_editor() and wc.records("participants"):
        with st.form("trial_form", clear_on_submit=True):
            person = wc.pick_participant(key="trial_participant")
            task = st.selectbox("Task", config.EVALUATION_TASKS, key="trial_task")
            method = st.selectbox("Method", config.TASK_METHODS, key="trial_method")
            seconds = st.text_input("Time taken in seconds", key="trial_seconds")
            done = st.radio("Was the task completed correctly?", ("Yes", "No"),
                            horizontal=True, key="trial_success")
            submitted = st.form_submit_button("Save trial")
        if submitted:
            def save_trial() -> str:
                """Save one timed attempt."""
                with wc.connect() as conn:
                    new_id = operations.create_record(conn, "task_trials", {
                        "participant_id": person, "task_name": task, "method": method,
                        "seconds": validation.seconds(seconds), "success": int(done == "Yes"),
                        "recorded_at": wc.now_text()})
                return f"Saved with ID {new_id}."
            wc.run_action(save_trial)
    elif wc.can_edit():
        st.info("Add a participant first.")

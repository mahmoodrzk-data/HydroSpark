"""Import readings, back up and restore all data, and reset the database."""
import csv
import io
import os
import tempfile
from pathlib import Path

import streamlit as st

import data_store
import importer
import operations
import seed_data
import web_common as wc

wc.start_page("Data, import and backup")
with wc.connect() as conn:
    counts = data_store.row_counts(conn)
st.subheader("What is stored now")
wc.show_table([{"table": table, "rows": number} for table, number in counts.items()])
st.info("Streamlit Community Cloud deletes this database whenever the app restarts. "
        "After every session: download a backup, unzip it, and upload the CSV files into "
        "the data/live folder of your GitHub repository. On restart the app loads data/live.")

if not wc.require_editor():
    st.stop()

import_tab, backup_tab, restore_tab, reset_tab = st.tabs(
    ["Import readings (CSV)", "Download backup", "Restore backup", "Reset"])

with import_tab:
    template = io.StringIO()
    csv.writer(template).writerow(importer.TEMPLATE_COLUMNS)
    st.download_button("Download blank template", data=template.getvalue().encode("utf-8"),
                       file_name="import_template.csv", mime="text/csv", key="download_template")
    st.write("One row per reading. Stations and observers must already exist. "
             "Every row is checked; bad rows are skipped and explained.")
    upload = st.file_uploader("CSV file of readings", type=["csv"], key="import_file")
    if upload is not None and st.button("Import readings", key="import_button"):
        handle, temp_name = tempfile.mkstemp(suffix=".csv")
        try:
            with os.fdopen(handle, "wb") as temp:
                temp.write(upload.getvalue())
            with wc.connect() as conn:
                result = importer.import_readings(conn, Path(temp_name))
        except (ValueError, UnicodeDecodeError, csv.Error) as error:
            st.error(f"Cannot import: {error}")
        else:
            st.success(f"Imported {result['accepted']} reading(s). "
                       f"Skipped {len(result['rejected'])}.")
            wc.show_table(result["rejected"], "No rows were skipped.")
        finally:
            Path(temp_name).unlink(missing_ok=True)

with backup_tab:
    with wc.connect() as conn:
        backup = data_store.backup_zip(conn)
    st.download_button("Download full backup (zip of CSV files)", data=backup,
                       file_name=f"hydrosight_backup_{wc.now_text()[:10]}.zip",
                       mime="application/zip", key="download_backup",
                       on_click=wc.log_use, args=("export", "Full backup (web)"))
    st.write("The zip holds one CSV file per table, including the activity log and the "
             "anonymous evaluation data. Keep your GitHub repository private.")

with restore_tab:
    st.write("Replaces EVERYTHING in the database with the backup. If any row in the backup "
             "is wrong, nothing is changed.")
    backup_file = st.file_uploader("Backup zip made by HydroSight", type=["zip"],
                                   key="restore_file")
    confirm = st.text_input("Type REPLACE to confirm", key="restore_confirm")
    if backup_file is not None and st.button("Restore backup", key="restore_button"):
        def restore() -> str:
            """Load every table from the zip in one transaction."""
            if confirm != "REPLACE":
                raise ValueError("Type REPLACE (in capital letters) to confirm.")
            tables = data_store.read_zip(backup_file.getvalue())
            with wc.connect() as conn:
                loaded = data_store.replace_all(conn, tables)
                operations.log_activity(conn, "import", "", None,
                                        f"Restored backup {backup_file.name}")
            return "Restored: " + ", ".join(f"{t} {n}" for t, n in loaded.items())
        wc.run_action(restore)

with reset_tab:
    st.write("Use this once, before real monitoring starts, to remove the SYNTHETIC demo data. "
             "Download a backup first.")
    choice = st.radio("Replace everything with", ("An empty database", "The SYNTHETIC demo data"),
                      key="reset_choice")
    confirm = st.text_input("Type RESET to confirm", key="reset_confirm")
    if st.button("Reset the database", key="reset_button"):
        def reset() -> str:
            """Delete all rows, then optionally reload the demo data."""
            if confirm != "RESET":
                raise ValueError("Type RESET (in capital letters) to confirm.")
            with wc.connect() as conn:
                data_store.clear_all(conn)
                if choice == "The SYNTHETIC demo data":
                    seed_data.load(conn, seed_data.build_rows())
            return f"Done: the database now holds {choice.lower()}."
        wc.run_action(reset)

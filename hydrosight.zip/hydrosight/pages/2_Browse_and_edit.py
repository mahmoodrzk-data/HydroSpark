"""Browse and search every table; team members can also update or delete records."""
import streamlit as st

import config
import main
import operations
import validation
import web_common as wc

wc.start_page("Browse and edit")
TABLES = {"Water readings": "readings", "Pollution incidents": "incidents",
          "Stations": "stations", "Observers": "observers", "Activity log": "activity_log"}
PRIVATE = {"Participants": "participants", "SUS responses": "sus_responses",
           "Task trials": "task_trials"}   # evaluation data: team members only
if wc.can_edit():
    TABLES.update(PRIVATE)

label = st.radio("Table", list(TABLES), horizontal=True, key="browse_table")
table = TABLES[label]
filters = wc.sidebar_filters()

with wc.connect() as conn:
    if table == "readings":
        rows = main.reading_rows(operations.search_readings(conn, **filters))
        if st.checkbox("Flagged readings only (WATCH or CRITICAL)", key="browse_flagged"):
            rows = [r for r in rows if r["flag"] in ("WATCH", "CRITICAL")]
    elif table == "incidents":
        left, middle, right = st.columns(3)
        kind = left.selectbox("Incident type", (None, *config.INCIDENT_TYPES), key="browse_kind",
                              format_func=lambda k: "All types" if k is None else k)
        status = middle.selectbox("Status", (None, *config.STATUSES), key="browse_status",
                                  format_func=lambda s: "All statuses" if s is None else s)
        keyword = right.text_input("Word in description", key="browse_keyword")
        rows = operations.search_incidents(conn, **filters, incident_type=kind, status=status,
                                           keyword=keyword.strip() or None)
    elif table == "activity_log":
        rows = operations.list_activity(conn, filters["start"], filters["end"])
    else:
        rows = operations.list_records(conn, table)
wc.show_table(rows)
st.caption(f"{len(rows)} record(s). Filters in the sidebar apply to readings, incidents "
           "and the activity log.")

if table == "activity_log" or not wc.can_edit():
    st.stop()

st.divider()
st.subheader(f"Change or delete a record in {label.lower()}")
id_text = st.text_input("Record ID", key="edit_id")
if not id_text.strip():
    st.stop()
try:
    record_id = validation.positive_int(id_text)
except ValueError as error:
    st.error(str(error))
    st.stop()
with wc.connect() as conn:
    record = operations.get_record(conn, table, record_id)
if record is None:
    st.error("No record has that ID.")
    st.stop()
wc.show_table([record])

update_tab, delete_tab = st.tabs(["Update one field", "Delete this record"])
with update_tab:
    field = st.selectbox("Field to change", main.form_fields(table), key="edit_field")
    if field in main.OPTIONS:
        new_value = st.selectbox("New value", main.OPTIONS[field], key="edit_choice")
    else:
        prompt, check = main.FIELDS[field]
        text = st.text_input(f"New value: {prompt}", key="edit_text")
    resolved_text = ""
    if table == "incidents" and field == "status":
        resolved_text = st.text_input("Resolved at, YYYY-MM-DD HH:MM (only for Closed)",
                                      key="edit_resolved")
    if st.button("Save change", key="edit_save"):
        def save_change() -> str:
            """Check the new value with the same rule as the command-line program, then save."""
            value = new_value if field in main.OPTIONS else check(text)
            changes = {field: value}
            if table == "incidents" and field == "status":
                changes["resolved_at"] = (validation.resolved_time(resolved_text,
                                                                   record["observed_at"])
                                          if value == "Closed" else None)
            with wc.connect() as conn:
                if not operations.update_record(conn, table, record_id, changes):
                    raise ValueError("Nothing was changed.")
            return "Updated."
        wc.run_action(save_change)

with delete_tab:
    st.write("Deleting cannot be undone. Records still used by other records are protected.")
    confirm = st.text_input("Type DELETE to confirm", key="delete_confirm")
    if st.button("Delete record", key="delete_button"):
        def delete() -> str:
            """Delete only after the user typed DELETE."""
            if confirm != "DELETE":
                raise ValueError("Type DELETE (in capital letters) to confirm.")
            with wc.connect() as conn:
                operations.delete_record(conn, table, record_id)
            return "Deleted."
        wc.run_action(delete)

"""Analysis: overview, one station in detail, period comparison, incidents and WQI calculator."""
from collections import Counter
from datetime import datetime

import pandas as pd
import streamlit as st

import analytics
import config
import main
import operations
import validation
import web_common as wc
import wqi

wc.start_page("Analytics")
filters = wc.sidebar_filters()
overview_tab, station_tab, compare_tab, incident_tab, calculator_tab = st.tabs(
    ["Overview", "One station", "Compare two periods", "Incident response", "WQI calculator"])

with overview_tab:
    with wc.connect() as conn:
        st.text(main.build_summary(conn, filters))
    st.caption("Uses the filters in the sidebar.")

with station_tab:
    with st.form("station_analysis"):
        station_id = wc.pick_station(key="analysis_station")
        parameter = wc.pick_parameter("analysis_parameter")
        submitted = st.form_submit_button("Analyse")
    if submitted and station_id is not None:
        wc.log_use("analysis", "One station in detail")
        with wc.connect() as conn:
            rows = analytics.add_wqi(operations.search_readings(conn, station_id=station_id))
        stats = analytics.describe(rows, parameter)
        st.markdown(f"**{config.LABELS[parameter]}**: n = {stats['n']}, "
                    f"missing = {stats['missing']}")
        tiles = st.columns(5)
        for tile, key in zip(tiles, ("mean", "median", "sd", "min", "max")):
            tile.metric(key.upper() if key == "sd" else key.capitalize(),
                        "n/a" if stats[key] is None else f"{stats[key]:.2f}")
        months = analytics.monthly_means(rows, parameter)
        if months:
            smooth = analytics.moving_average([mean for _, _, mean in months])
            table = pd.DataFrame({"month": [m for m, _, _ in months],
                                  "n": [n for _, n, _ in months],
                                  "mean": [round(v, 2) for _, _, v in months],
                                  "3-month average": [wc.rounded(v, 2) for v in smooth]})
            st.line_chart(table.set_index("month")[["mean", "3-month average"]])
            wc.show_table(table.to_dict("records"))
        trend = analytics.trend_summary(rows, parameter)
        p_text = "n/a" if trend["p"] is None else f"{trend['p']:.4f}"
        slope = "n/a" if trend["slope_30d"] is None else f"{trend['slope_30d']:.2f}"
        st.write(f"Mann-Kendall trend test: **{trend['trend']}** (S = {trend['s']}, "
                 f"n = {trend['n']}, p = {p_text}). Sen's slope: {slope} per 30 days "
                 "(a description, not a forecast).")
        if parameter == "wqi":
            classes = Counter(r["wqi_class"] for r in rows if r["wqi_class"])
            st.write("WQI classes: " + (", ".join(f"Class {c}: {classes[c]}"
                                                  for c in sorted(classes)) or "none yet"))
        st.markdown("**Unusual values to verify** (not automatically errors)")
        wc.show_table([{"reading_id": r["reading_id"], "sampled_at": r["sampled_at"],
                        "value": round(r[parameter], 2), "modified_z": round(z, 2)}
                       for r, z in analytics.find_outliers(rows, parameter)],
                      "No unusual values found.")

with compare_tab:
    with st.form("compare_form"):
        station_id = wc.pick_station(key="compare_station")
        parameter = wc.pick_parameter("compare_parameter")
        first, second = st.columns(2)
        dates = [first.date_input("Period 1 start", key="p1_start"),
                 first.date_input("Period 1 end", key="p1_end"),
                 second.date_input("Period 2 start", key="p2_start"),
                 second.date_input("Period 2 end", key="p2_end")]
        submitted = st.form_submit_button("Compare")
    if submitted and station_id is not None:
        def compare() -> str:
            """Check the periods, then compare the two means."""
            p1_start, p1_end, p2_start, p2_end = (d.isoformat() for d in dates)
            validation.date_range(p1_start, p1_end)
            validation.date_range(p2_start, p2_end)
            if p1_end >= p2_start:
                raise ValueError("Period 2 must start after Period 1 ends.")
            with wc.connect() as conn:
                one = analytics.add_wqi(
                    operations.search_readings(conn, station_id, p1_start, p1_end))
                two = analytics.add_wqi(
                    operations.search_readings(conn, station_id, p2_start, p2_end))
            result = analytics.compare_periods(one, two, parameter)
            wc.log_use("analysis", "Compare two periods")
            means = [f"Period {n}: n = {result[k]['n']}, mean = "
                     f"{'n/a' if result[k]['mean'] is None else round(result[k]['mean'], 2)}"
                     for n, k in ((1, "first"), (2, "second"))]
            change = "n/a" if result["change"] is None else f"{result['change']:.2f}"
            return (f"{means[0]}. {means[1]}. Change (period 2 minus period 1): {change}. "
                    "A difference does not show what caused it.")
        wc.run_action(compare)

with incident_tab:
    with wc.connect() as conn:
        incidents = operations.search_incidents(conn, **filters)
    result = analytics.response_times(incidents, datetime.now().strftime(config.TIME_FORMAT))
    tiles = st.columns(4)
    tiles[0].metric("Incidents", result["total"])
    tiles[1].metric("Closed", result["closed"])
    tiles[2].metric("Median days to close",
                    "n/a" if result["median_days"] is None else f"{result['median_days']:.1f}")
    tiles[3].metric(f"Unresolved over {config.BACKLOG_DAYS} days", result["overdue"])
    st.caption("Uses the filters in the sidebar.")

with calculator_tab:
    st.write("Enter one sample's values. All seven are needed. Nothing is saved.")
    with st.form("calculator_form"):
        columns = st.columns(4)
        texts = {name: columns[i % 4].text_input(config.MEASURES[name][0], key=f"calc_{name}")
                 for i, name in enumerate(main.WQI_INPUTS)}
        submitted = st.form_submit_button("Calculate WQI")
    if submitted:
        try:
            sample = {name: validation.required_measurement(texts[name], name)
                      for name in main.WQI_INPUTS}
        except ValueError as error:
            st.error(f"Cannot continue: {error}")
        else:
            wc.log_use("analysis", "WQI calculator")
            st.write(f"Dissolved oxygen saturation: "
                     f"{wqi.do_percent(sample['dissolved_oxygen'], sample['temperature']):.1f}%")
            wc.show_table([{"sub_index": name.upper(), "value": round(value, 2),
                            "weight": config.WQI_WEIGHTS[name],
                            "weighted": round(value * config.WQI_WEIGHTS[name], 2)}
                           for name, value in wqi.sub_indices(sample).items()])
            value = wqi.calculate_wqi(sample)
            st.success(f"WQI = {value:.1f}: Class {wqi.wqi_class(value)}, {wqi.wqi_status(value)}")

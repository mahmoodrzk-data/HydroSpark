"""Report layer: CSV files and plain-text summaries."""
import csv
from datetime import datetime
from pathlib import Path

import analytics
import config


def new_path(folder: Path, stem: str, suffix: str) -> Path:
    """Create the folder and return a new time-stamped file name."""
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"{stem}_{datetime.now():%Y%m%d_%H%M%S_%f}{suffix}"


def safe_cell(value: object) -> object:
    """Stop spreadsheet programs from running user text as a formula."""
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def export_csv(rows: list[dict], stem: str, folder: Path = config.REPORT_DIR) -> Path:
    """Write dictionaries to a new CSV file and return its path."""
    if not rows:
        raise ValueError("There are no rows to export.")
    path = new_path(folder, stem, ".csv")
    with path.open("x", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows({k: safe_cell(v) for k, v in row.items()} for row in rows)
    return path


def export_text(text: str, stem: str = "summary", folder: Path = config.REPORT_DIR) -> Path:
    """Write text to a new file and return its path."""
    path = new_path(folder, stem, ".txt")
    path.write_text(text, encoding="utf-8")
    return path


def number(value: float | None, places: int = 1) -> str:
    """Format a number, showing n/a when it is unavailable."""
    return "n/a" if value is None else f"{value:.{places}f}"


def percent(value: float | None) -> str:
    """Format a 0-1 proportion as a percentage."""
    return "n/a" if value is None else f"{value:.0%}"


def summary_text(stations: list[dict], readings: list[dict], incidents: list[dict],
                 period: str = "All dates", now: str | None = None) -> str:
    """Build the stakeholder summary as one string."""
    now = now or datetime.now().strftime(config.TIME_FORMAT)
    rows = analytics.add_wqi(readings)
    sources = sorted({row["data_source"] for row in readings + incidents})
    ready = sum(row["wqi"] is not None for row in rows)
    lines = [f"{config.APP_NAME.upper()} RIVER QUALITY SUMMARY",
             f"Generated: {now}", f"Period: {period}",
             f"Data sources: {', '.join(sources) or 'no records'}"]
    if "synthetic" in sources:
        lines.append("WARNING: contains SYNTHETIC test data. Not real river measurements.")
    lines += [f"Readings: {len(readings)} (WQI calculated for {ready})   Incidents: {len(incidents)}",
              "", "FOLLOW-UP RANKING (lowest mean DOE-WQI first)"]
    for row in analytics.rank_stations(stations, readings, incidents):
        if row["mean_wqi"] is None:
            quality = "no WQI yet"
        else:
            quality = (f"mean WQI {row['mean_wqi']:.1f}, Class {row['wqi_class']}, "
                       f"{row['wqi_status']} (n={row['wqi_samples']})")
        lines.append(f"{row['station']}: {quality}; field checks passed "
                     f"{number(row['screening_score'])}%; critical flags {row['critical']}; "
                     f"incidents {row['incidents']}; open severity {row['open_severity']}")
    lines += ["", "WQI TREND (Mann-Kendall test; Sen's slope = WQI points per 30 days)"]
    for station in stations:
        own = [row for row in rows if row["station_id"] == station["station_id"]]
        trend = analytics.trend_summary(own, "wqi")
        detail = f"p = {trend['p']:.3f}" if trend["p"] is not None else f"n = {trend['n']}"
        lines.append(f"{station['code']}: {trend['trend']} ({detail}); "
                     f"slope {number(trend['slope_30d'], 2)}")
    lines += ["", "FIELD SCREENING (outside Class IIB limits, selected stations pooled)"]
    for name in config.SCREENING_LIMITS:
        result = analytics.exceedance(readings, name)
        if result["n"]:
            low, high = result["interval"]
            lines.append(f"{config.LABELS[name]}: {result['outside']}/{result['n']} = "
                         f"{result['rate']:.1%} (approx. 95% interval {low:.1%} to {high:.1%})")
        else:
            lines.append(f"{config.LABELS[name]}: no data")
    found = analytics.incident_summary(incidents)
    response = analytics.response_times(incidents, now)
    lines += ["", "INCIDENTS"]
    lines += [f"{kind}: {count}" for kind, count in sorted(found["by_type"].items())]
    if found["total"]:
        lines += [f"Most incidents: {', '.join(found['peak_sites'])} "
                  f"({found['peak_count']} incident(s) per site)",
                  f"Closed: {response['closed']} of {response['total']}; median days to close: "
                  f"{number(response['median_days'])}; unresolved for over "
                  f"{config.BACKLOG_DAYS} days: {response['overdue']}"]
    lines += ["", "LIMITATIONS",
              "The WQI needs laboratory values (BOD, COD, ammoniacal nitrogen, TSS).",
              "Screening only: not proof of safety, pollution source or legal breach.",
              "Intervals and trend tests assume independent readings; river data may not be.",
              "Incident counts depend on how often each site was visited."]
    return "\n".join(lines) + "\n"


def impact_text(usage: dict, sus: dict, tasks: list[dict], pairs: dict, quality: dict,
                response: dict, period: str) -> str:
    """Build the evaluation and impact report as one string."""
    lines = [f"{config.APP_NAME.upper()} EVALUATION AND IMPACT REPORT",
             f"Generated: {datetime.now():%Y-%m-%d %H:%M}", f"Period: {period}", "",
             "1. HOW THE SYSTEM WAS USED (activity log)",
             f"Logged actions: {usage['events']} over {usage['active_days']} active day(s)"]
    lines += [f"  {action}: {count}" for action, count in sorted(usage["by_action"].items())]
    lines += [f"  records created in {table}: {count}"
              for table, count in sorted(usage["created_by_table"].items())]
    lines += ["", "2. USABILITY (System Usability Scale, 0-100)"]
    if sus["n"]:
        lines += [f"Respondents: {sus['n']}; mean {sus['mean']:.1f}; median {sus['median']:.1f}; "
                  f"SD {number(sus['sd'])}; range {sus['min']:.1f}-{sus['max']:.1f}",
                  f"At or above the common benchmark of {config.SUS_BENCHMARK:g}: "
                  f"{percent(sus['share_at_benchmark'])}"]
    else:
        lines.append("No SUS responses recorded yet.")
    lines += ["", "3. TIME ON TASK (manual method versus HydroSight)"]
    for row in tasks:
        lines.append(f"{row['task']}: manual {number(row['manual_mean_s'])} s (n={row['manual_n']}, "
                     f"success {percent(row['manual_success'])}); software "
                     f"{number(row['software_mean_s'])} s (n={row['software_n']}, success "
                     f"{percent(row['software_success'])}); time saved "
                     f"{number(row['time_saved_pct'])}%")
    lines.append(f"Paired comparisons: {pairs['pairs']}; median saving "
                 f"{number(pairs['median_saving_pct'])}%; faster with software in "
                 f"{percent(pairs['share_faster'])} of pairs")
    lines += ["", "4. DATA QUALITY AND FOLLOW-UP",
              f"Readings: {quality['n']}; WQI-ready: {quality['wqi_ready']} "
              f"({number(quality['wqi_ready_pct'])}%)",
              "Completeness by measurement: " + ", ".join(
                  f"{name} {number(value, 0)}%" for name, value in quality["completeness"].items()),
              f"Incidents closed: {response['closed']} of {response['total']}; median days "
              f"to close {number(response['median_days'])}; overdue {response['overdue']}",
              "", "INTERPRETATION LIMITS",
              "Small, non-random groups of testers cannot represent all users.",
              "Time savings depend on the tasks chosen and on practice.",
              "Better records do not by themselves improve river water quality."]
    return "\n".join(lines) + "\n"

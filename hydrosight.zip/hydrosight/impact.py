"""Evaluation layer: how the system is used, how usable it is, and time saved."""
import statistics
from collections import Counter

import config


def sus_score(response: dict) -> float:
    """System Usability Scale score (0-100) for one completed questionnaire."""
    total = 0
    for number in range(1, 11):
        answer = response[f"q{number}"]
        if not 1 <= answer <= 5:
            raise ValueError("SUS answers must be from 1 to 5.")
        if number % 2 == 1:          # odd items are positive statements
            total += answer - 1
        else:                        # even items are negative statements
            total += 5 - answer
    return total * 2.5


def sus_summary(responses: list[dict]) -> dict:
    """Mean, spread and share of SUS scores at or above the common benchmark."""
    scores = [sus_score(r) for r in responses]
    return {
        "n": len(scores),
        "mean": statistics.fmean(scores) if scores else None,
        "median": statistics.median(scores) if scores else None,
        "sd": statistics.stdev(scores) if len(scores) >= 2 else None,
        "min": min(scores, default=None),
        "max": max(scores, default=None),
        "share_at_benchmark": (sum(s >= config.SUS_BENCHMARK for s in scores) / len(scores)
                               if scores else None),
    }


def task_comparison(trials: list[dict]) -> list[dict]:
    """For each task, compare mean time and success of manual work versus the software."""
    rows = []
    for task in config.EVALUATION_TASKS:
        manual = [t for t in trials if t["task_name"] == task and t["method"] == "manual"]
        software = [t for t in trials if t["task_name"] == task and t["method"] == "software"]
        manual_mean = statistics.fmean(t["seconds"] for t in manual) if manual else None
        software_mean = statistics.fmean(t["seconds"] for t in software) if software else None
        saved = None
        if manual_mean and software_mean is not None:
            saved = 100 * (manual_mean - software_mean) / manual_mean
        rows.append({
            "task": task,
            "manual_n": len(manual),
            "manual_mean_s": manual_mean,
            "manual_success": (statistics.fmean(t["success"] for t in manual) if manual else None),
            "software_n": len(software),
            "software_mean_s": software_mean,
            "software_success": (statistics.fmean(t["success"] for t in software)
                                 if software else None),
            "time_saved_pct": saved,
        })
    return rows


def paired_savings(trials: list[dict]) -> dict:
    """Percent time saved for each participant who did the same task both ways."""
    times = {(t["participant_id"], t["task_name"], t["method"]): t["seconds"] for t in trials}
    savings = []
    for (person, task, method), manual_time in times.items():
        software_time = times.get((person, task, "software"))
        if method == "manual" and software_time is not None:
            savings.append(100 * (manual_time - software_time) / manual_time)
    return {
        "pairs": len(savings),
        "median_saving_pct": statistics.median(savings) if savings else None,
        "share_faster": (sum(s > 0 for s in savings) / len(savings) if savings else None),
    }


def usage_summary(log_rows: list[dict]) -> dict:
    """Count how the system was used, from the activity log."""
    return {
        "events": len(log_rows),
        "by_action": Counter(row["action"] for row in log_rows),
        "created_by_table": Counter(row["table_name"] for row in log_rows
                                    if row["action"] == "create"),
        "active_days": len({row["logged_at"][:10] for row in log_rows}),
        "first": log_rows[0]["logged_at"] if log_rows else None,
        "last": log_rows[-1]["logged_at"] if log_rows else None,
    }


def data_quality(readings: list[dict]) -> dict:
    """Completeness of each measurement and how many readings can produce a WQI."""
    n = len(readings)
    complete = {name: (100 * sum(r[name] is not None for r in readings) / n if n else None)
                for name in config.MEASURES}
    ready = sum(all(r[name] is not None for name in ("ph", "dissolved_oxygen", "temperature",
                                                     *config.LAB_MEASURES))
                for r in readings)
    return {"n": n, "completeness": complete,
            "wqi_ready": ready, "wqi_ready_pct": 100 * ready / n if n else None,
            "sources": Counter(r["data_source"] for r in readings)}

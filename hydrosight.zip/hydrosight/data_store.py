"""Back up and restore every table as CSV files.

Used by the web app. Streamlit Community Cloud deletes local files when the app restarts,
so the team downloads a backup after each session and keeps it in data/live on GitHub.
When the app starts with an empty database, it loads data/live again.
"""
import csv
import io
import math
import sqlite3
import zipfile
from pathlib import Path

from database import fetch_all

# Parents come before children, so foreign keys are satisfied while loading.
TABLE_ORDER: tuple[str, ...] = ("stations", "observers", "readings", "incidents",
                                "participants", "sus_responses", "task_trials", "activity_log")
MAX_BACKUP_BYTES: int = 20_000_000   # refuse unpacked backups larger than about 20 MB


def table_columns(conn: sqlite3.Connection, table: str) -> list[dict]:
    """Name, type and NOT NULL flag of each column in one approved table."""
    if table not in TABLE_ORDER:
        raise ValueError("Unknown table.")
    return [{"name": row["name"], "type": row["type"].upper(), "notnull": bool(row["notnull"])}
            for row in conn.execute(f"PRAGMA table_info({table})")]


def is_empty(conn: sqlite3.Connection) -> bool:
    """True when the database has no stations yet."""
    return conn.execute("SELECT 1 FROM stations LIMIT 1").fetchone() is None


def row_counts(conn: sqlite3.Connection) -> dict[str, int]:
    """Number of rows in every table."""
    return {table: conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in TABLE_ORDER}


def tables_to_csv(conn: sqlite3.Connection) -> dict[str, str]:
    """Each table as CSV text, with a heading row even when the table is empty."""
    files = {}
    for table in TABLE_ORDER:
        names = [column["name"] for column in table_columns(conn, table)]
        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=names, lineterminator="\n")
        writer.writeheader()
        writer.writerows(fetch_all(conn, f"SELECT * FROM {table} ORDER BY rowid"))
        files[f"{table}.csv"] = buffer.getvalue()
    return files


def backup_zip(conn: sqlite3.Connection) -> bytes:
    """All tables in one zip file, ready to download."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, text in tables_to_csv(conn).items():
            archive.writestr(name, text)
    return buffer.getvalue()


def write_folder(conn: sqlite3.Connection, folder: Path) -> list[Path]:
    """Save every table as a CSV file inside a folder, such as data/live."""
    folder.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, text in tables_to_csv(conn).items():
        path = folder / name
        path.write_text(text, encoding="utf-8")
        paths.append(path)
    return paths


def read_zip(data: bytes) -> dict[str, list[dict]]:
    """Read the table CSV files inside a backup zip. Other files are ignored."""
    wanted = {f"{table}.csv": table for table in TABLE_ORDER}
    tables: dict[str, list[dict]] = {}
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members = [m for m in archive.infolist() if Path(m.filename).name in wanted]
            if sum(m.file_size for m in members) > MAX_BACKUP_BYTES:
                raise ValueError("The backup is too large.")
            for member in members:
                text = archive.read(member).decode("utf-8-sig")
                tables[wanted[Path(member.filename).name]] = list(csv.DictReader(io.StringIO(text)))
    except zipfile.BadZipFile:
        raise ValueError("That file is not a zip backup made by HydroSight.") from None
    except UnicodeDecodeError:
        raise ValueError("The backup files must be UTF-8 CSV files.") from None
    return tables


def read_folder(folder: Path) -> dict[str, list[dict]]:
    """Read the table CSV files saved in a folder. Returns {} if there are none."""
    tables = {}
    for table in TABLE_ORDER:
        path = folder / f"{table}.csv"
        if path.is_file():
            with path.open(newline="", encoding="utf-8-sig") as handle:
                tables[table] = list(csv.DictReader(handle))
    return tables


def convert(text: str | None, column: dict) -> object:
    """Turn CSV text back into the column's type. A blank cell means no value."""
    if text is None or text == "":
        return "" if column["notnull"] and column["type"] == "TEXT" else None
    if column["type"] == "INTEGER":
        number = float(text)
        if not number.is_integer():
            raise ValueError(f"{column['name']} must be a whole number.")
        return int(number)
    if column["type"] == "REAL":
        number = float(text)
        if not math.isfinite(number):
            raise ValueError(f"{column['name']} must be a normal number.")
        return number
    return text


def clear_all(conn: sqlite3.Connection) -> None:
    """Delete every row from every table (children first)."""
    for table in reversed(TABLE_ORDER):
        conn.execute(f"DELETE FROM {table}")


def replace_all(conn: sqlite3.Connection, tables: dict[str, list[dict]]) -> dict[str, int]:
    """Delete everything, then load the given tables with their original IDs.

    Runs inside the caller's transaction: if any row is wrong, nothing is changed.
    """
    if "stations" not in tables:
        raise ValueError("The backup has no stations.csv file.")
    clear_all(conn)
    counts = {}
    for table in TABLE_ORDER:
        columns = {column["name"]: column for column in table_columns(conn, table)}
        rows = tables.get(table, [])
        for line, row in enumerate(rows, start=2):   # line 1 holds the headings
            unknown = [name for name in row if name not in columns]
            if unknown:
                raise ValueError(f"{table}.csv has unknown columns: {unknown}")
            try:
                values = {name: convert(row[name], columns[name]) for name in row}
                names = ", ".join(values)
                marks = ", ".join("?" for _ in values)
                conn.execute(f"INSERT INTO {table} ({names}) VALUES ({marks})",
                             tuple(values.values()))
            except (ValueError, sqlite3.IntegrityError) as error:
                raise ValueError(f"{table}.csv line {line}: {error}") from None
        counts[table] = len(rows)
    return counts

# data/live

Put the CSV files from a HydroSight backup zip here (stations.csv, observers.csv,
readings.csv, incidents.csv, participants.csv, sus_responses.csv, task_trials.csv,
activity_log.csv) and commit them to GitHub.

When the web app starts with an empty database, it loads these files.
If this folder has no stations.csv, the app loads the SYNTHETIC demo data instead.

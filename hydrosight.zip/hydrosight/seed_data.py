"""Create the SYNTHETIC seed dataset and load it into an empty database.

All stations, rivers, people and values here are invented for testing and demonstration.
Run once:  python seed_data.py
"""
import csv
import random
import sqlite3
from datetime import date, timedelta
from pathlib import Path

import config
import database
import operations

SEED_DIR: Path = config.BASE_DIR / "data" / "seed"
SEED_TABLES: tuple[str, ...] = ("stations", "observers", "readings", "incidents")
WEEKS: int = 24
# Station profile: field centres, and laboratory centres at (first week, last week).
# Station 4 improves over time; the others stay level.
PROFILES: dict[int, dict] = {
    1: {"ph": 7.2, "do": (6.6, 6.6), "turbidity": 20, "bod": (1.5, 1.5), "cod": (12, 12),
        "an": (0.15, 0.15), "tss": (15, 15)},
    2: {"ph": 6.8, "do": (5.3, 5.3), "turbidity": 42, "bod": (4, 4), "cod": (25, 25),
        "an": (0.6, 0.6), "tss": (45, 45)},
    3: {"ph": 6.3, "do": (4.2, 4.2), "turbidity": 65, "bod": (15, 15), "cod": (80, 80),
        "an": (3.0, 3.0), "tss": (90, 90)},
    4: {"ph": 7.0, "do": (4.4, 5.8), "turbidity": 48, "bod": (12, 4), "cod": (60, 25),
        "an": (2.0, 0.6), "tss": (80, 45)},
}


def centre(pair: tuple[float, float], week: int) -> float:
    """Straight-line change from the first week's value to the last week's value."""
    first, last = pair
    return first + (last - first) * week / (WEEKS - 1)


def noisy(rng: random.Random, value: float, spread: float = 0.15) -> float:
    """Add random variation of about 15% and keep the value positive."""
    return round(max(0.05, value * rng.gauss(1, spread)), 2)


def build_rows() -> dict[str, list[dict]]:
    """Generate the same invented records every time (fixed random seed)."""
    rng = random.Random(2026)
    stations = [{"code": f"SYN-{x}", "name": f"Demo Station {x}",
                 "river_name": f"Demo River {x}", "area": "Fictional test area"} for x in "ABCD"]
    observers = [{"name": f"Demo Observer {n}", "role": role} for n, role in
                 enumerate(("Team lead", "Volunteer", "Volunteer", "Reviewer"), start=1)]
    readings = []
    start = date(2026, 6, 1)
    for week in range(WEEKS):
        for station_id, p in PROFILES.items():
            reading = {
                "station_id": station_id, "observer_id": 1 + week % 3,
                "sampled_at": f"{start + timedelta(weeks=week)} {8 + station_id:02d}:00",
                "ph": round(rng.gauss(p["ph"], 0.25), 2),
                "dissolved_oxygen": round(max(0.1, rng.gauss(centre(p["do"], week), 0.45)), 2),
                "turbidity": round(max(1.0, rng.gauss(p["turbidity"], 6)), 1),
                "temperature": round(rng.gauss(28.0, 0.8), 1),
                "bod": None, "cod": None, "ammoniacal_nitrogen": None, "tss": None,
                "data_source": "synthetic", "notes": "SYNTHETIC test record"}
            if week % 2 == 0:   # laboratory results every second week
                reading.update(bod=noisy(rng, centre(p["bod"], week)),
                               cod=noisy(rng, centre(p["cod"], week)),
                               ammoniacal_nitrogen=noisy(rng, centre(p["an"], week)),
                               tss=noisy(rng, centre(p["tss"], week)))
            readings.append(reading)
    readings[8]["turbidity"] = 180.0          # deliberate unusual value at SYN-A
    readings[13]["dissolved_oxygen"] = None   # deliberate missing value at SYN-B
    readings[30]["ph"] = None                 # deliberate missing value at SYN-C
    incidents = []
    for station_id, count in {1: 2, 2: 5, 3: 9, 4: 4}.items():
        for k in range(count):
            kind = config.INCIDENT_TYPES[(station_id + k) % len(config.INCIDENT_TYPES)]
            observed = start + timedelta(days=17 * k + station_id)
            status = config.STATUSES[k % 3]
            resolved = observed + timedelta(days=2 + 3 * (k % 4))
            incidents.append({
                "station_id": station_id, "observer_id": 1 + k % 3,
                "observed_at": f"{observed} 15:00", "incident_type": kind,
                "severity": 1 + (station_id + k) % 3, "status": status,
                "description": f"SYNTHETIC example: {kind.lower()} observation",
                "resolved_at": f"{resolved} 10:00" if status == "Closed" else None,
                "data_source": "synthetic"})
    return {"stations": stations, "observers": observers,
            "readings": readings, "incidents": incidents}


def import_row(code: str, when: str, values: dict, note: str) -> dict:
    """One row in the import-file format; measurements not given are left blank."""
    blank = {name: "" for name in config.MEASURES}
    return {"station_code": code, "observer_name": "Demo Observer 1", "sampled_at": when,
            **blank, **values, "data_source": "synthetic", "notes": note}


def sample_import_rows() -> list[dict]:
    """A small SYNTHETIC import file: 3 good rows and 4 rows with deliberate errors."""
    full = {"ph": "7.1", "dissolved_oxygen": "6.2", "turbidity": "18", "temperature": "27.5",
            "bod": "2.1", "cod": "14", "ammoniacal_nitrogen": "0.2", "tss": "20"}
    field_only = {"ph": "6.9", "dissolved_oxygen": "5.6", "turbidity": "35", "temperature": "28"}
    return [
        import_row("SYN-A", "2026-11-23 09:30", full, "SYNTHETIC good row"),
        import_row("SYN-B", "2026-11-23 10:30",
                   {**full, "bod": "4.5", "ammoniacal_nitrogen": "0.7"}, "SYNTHETIC good row"),
        import_row("SYN-C", "2026-11-23 11:30", {**full, "ph": "15"},
                   "SYNTHETIC error: pH too high"),
        import_row("SYN-Z", "2026-11-23 12:30", full, "SYNTHETIC error: unknown station"),
        import_row("SYN-D", "2026-02-30 09:00", full, "SYNTHETIC error: impossible date"),
        import_row("SYN-A", "2026-06-01 09:00", full, "SYNTHETIC error: duplicate time"),
        import_row("SYN-D", "2026-11-24 12:30", field_only, "SYNTHETIC good row, field values only"),
    ]


def write_csv(path: Path, records: list[dict]) -> None:
    """Save records as a CSV file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def write_csv_files(rows: dict[str, list[dict]], folder: Path = SEED_DIR) -> None:
    """Save the dataset and the sample import file as CSV files that can be inspected."""
    for table, records in rows.items():
        write_csv(folder / f"{table}_SYNTHETIC.csv", records)
    write_csv(folder / "sample_import_SYNTHETIC.csv", sample_import_rows())


def load(conn: sqlite3.Connection, rows: dict[str, list[dict]]) -> bool:
    """Insert the dataset only if the monitoring tables are empty."""
    if any(operations.list_records(conn, table) for table in SEED_TABLES):
        return False
    for table in SEED_TABLES:   # parents come before children
        for record in rows[table]:
            operations.create_record(conn, table, record, log=False)
    return True


def main() -> None:
    """Initialise the database and load the synthetic data."""
    try:
        database.init_db()
        rows = build_rows()
        write_csv_files(rows)
        with database.open_db() as conn:
            loaded = load(conn, rows)
        print("Synthetic data loaded." if loaded
              else "Database already has monitoring data; nothing was changed.")
    except (sqlite3.Error, OSError) as error:
        print(f"Seeding failed: {error}")


if __name__ == "__main__":
    main()
